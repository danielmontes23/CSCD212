import cscd212classes.lab3.ObserverPatternClient;
import cscd212classes.observable.AwesomeDeals;

import cscd212classes.observers.EmailDeals;
import cscd212classes.observers.TextDeals;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

public class tester {

    @Test
    @DisplayName("Hourly Subscribed")
    public void testSubscribeHourly_NoException() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();

        String initialPhoneNumber = "123-456-7890";
        TextDeals textDeals = new TextDeals(awesomeDeals);
        textDeals.subscribeHourly(initialPhoneNumber);

        String newPhoneNumber = "509-786-2388";
        assertDoesNotThrow(() -> {
            textDeals.subscribeHourly(newPhoneNumber);
        });
    }

    @Test
    @DisplayName("Daily Subscribed")
    public void testSubscribeDaily_NoException() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();

        String initialPhoneNumber = "123-456-7890";
        TextDeals textDeals = new TextDeals(awesomeDeals);
        textDeals.subscribeDaily(initialPhoneNumber);

        String newPhoneNumber = "509-788-5454";
        assertDoesNotThrow(() -> {
            textDeals.subscribeDaily(newPhoneNumber);
        });
    }

    @Test
    @DisplayName("Hourly Subscribed")
    public void testSubscribeHourly() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();

        String initialPhoneNumber = "123-456-7890";
        TextDeals textDeals = new TextDeals(awesomeDeals);
        textDeals.subscribeHourly(initialPhoneNumber);

        String newPhoneNumber = "509-786-8823";
        assertThrows(IllegalStateException.class, () -> {
            textDeals.subscribeHourly(newPhoneNumber);
        });
    }

    @Test
    @DisplayName("Daily Subscribed")
    public void testSubscribeDaily() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();

        String initialPhoneNumber = "123-456-7890";
        TextDeals textDeals = new TextDeals(awesomeDeals);
        textDeals.subscribeHourly(initialPhoneNumber);

        String newPhoneNumber = "509-788-5114";
        assertThrows(IllegalStateException.class, () -> {
            textDeals.subscribeHourly(newPhoneNumber);
        });
    }

    @Test
    @DisplayName("AwesomeDeals Constructor")
    public void testDefaultConstructor() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();

        assertEquals("Daily Deal", awesomeDeals.getDaily());

        assertEquals("Hourly Deal", awesomeDeals.getHourly());
    }

    @Test
    @DisplayName("AwesomeDeals.Hourly")
    public void getHourly() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();
        assertEquals("Hourly Deal", awesomeDeals.getHourly());
    }

    @Test
    @DisplayName("AwesomeDeals.Daily")
    public void getDaily() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();
        assertEquals("Daily Deal", awesomeDeals.getDaily());
    }

    @Test
    @DisplayName("AwesomeDeals")
    public void testChangeDaily() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();

        String initialDailyDeal = "Initial Daily Deal";
        awesomeDeals.changeDaily(initialDailyDeal);

        String newDailyDeal = "New Daily Deal";
        awesomeDeals.changeDaily(newDailyDeal);

        assertEquals(newDailyDeal, awesomeDeals.getDaily());
    }

    @Test
    @DisplayName("AwesomeDeals")
    public void testChangeHourly() {
        AwesomeDeals awesomeDeals = new AwesomeDeals();

        String initialDailyDeal = "Initial Hourly Deal";
        awesomeDeals.changeDaily(initialDailyDeal);

        String newHourlyDeal = "Hourly Deal";
        awesomeDeals.changeDaily(newHourlyDeal);

        assertEquals(newHourlyDeal, awesomeDeals.getHourly());
    }
}
