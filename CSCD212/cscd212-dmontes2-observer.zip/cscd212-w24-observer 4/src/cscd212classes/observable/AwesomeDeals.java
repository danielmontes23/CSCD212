package cscd212classes.observable;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public class AwesomeDeals extends Object{
    //private String daily;
    //private String hourly;
    //private PropertyChangeSupport support;
    private String daily = "Daily Deal";
    private String hourly = "Hourly Deal";
    private PropertyChangeSupport support;

    /**
     * The default value constructor that sets daily to Daily Deal and hourly to Hourly Deal.
     * It also creates a property change support for this class.
     */
    public AwesomeDeals(){
        this.support = new PropertyChangeSupport(this);
    }

    /**
     * The subscribeDaily method allows an observer to subscribe to the daily deals.
     * This method fires a property change event with Subscribed Daily, null and the value in this daily data member
     */
    public void subscribeDaily(){
        support.firePropertyChange("Subscribed Daily", null, daily);
    }

    /**
     * The subscribeHour method allows an observer to subscribe to the hour deals.
     * This method fires a property change event with Subscribed Hourly, null and the value in this hourly data member
     */
    public void subscribeHourly(){
        support.firePropertyChange("Subscribed Hourly", null, hourly);
    }

    /**
     * The changeDaily method how the daily deals are changed.
     * This method saves the old daily deal
     * Updates the daily class level data member to the new daily deal
     * Finally it calls the fire property change passing New Daily the old and new values
     * @param daily
     */
    public void changeDaily(String daily){
        String oldDaily = this.daily;
        this.daily = daily;

        support.firePropertyChange("New Daily", oldDaily, daily);
    }

    /**
     * The changeHourly method how the hourly deals are changed.
     * This method saves the old hourly deal, updates the hourly class level data member to the new hourly deal
     * Finally it calls the fire property change passing New Hourly the old and new values
     * @param hourly
     */
    public void changeHourly(String hourly){
        String oldHourly = this.hourly;
        this.hourly = hourly;

        support.firePropertyChange("New Hourly", oldHourly, hourly);
    }

    /**
     * The getHourly method returns the class level value for hourly
     * @return
     */
    public String getHourly(){
        return hourly;
    }

    /**
     * The getDaily method returns the class level value for daily
     * @return
     */
    public String getDaily(){
        return daily;
    }

    /**
     * The addPropertyChangeListener adds to the support class level variable.
     * This is what actually adds the observer so it can be notified of property changes
     * @param pcl
     */
    public void addPropertyChangeListener(PropertyChangeListener pcl){
        support.addPropertyChangeListener(pcl);
    }

    /**
     * The removePropertyChangeListener removes from the support class level variable.
     * This is what actually removes the observer so it will no longer be notified of property changes
     * @param pcl
     */
    public void removePropertyChangeListener(PropertyChangeListener pcl){
        support.removePropertyChangeListener(pcl);
    }
}


