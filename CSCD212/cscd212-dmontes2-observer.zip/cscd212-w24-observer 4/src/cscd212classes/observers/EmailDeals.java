package cscd212classes.observers;

import cscd212classes.observable.AwesomeDeals;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class EmailDeals implements PropertyChangeListener {
    private String email1;
    private String email2;
    private AwesomeDeals awesomeDeals;

    /**
     * This EVC receives the object being observed.
     * It sets the class level variable for AwesomeDeals
     * And it add this class to the property change listener
     * @param awesomeDeals
     */
    public EmailDeals(AwesomeDeals awesomeDeals){
        this.awesomeDeals = awesomeDeals;
        this.awesomeDeals.addPropertyChangeListener(this);
    }

    /**
     * This subscribes the incoming email to daily subscriptions.
     * It assigns the email to the class level variable email1
     * And it calls the object being observed subscribe daily method so a property change event can be fired off
     * @param email
     */
    public void subscribeDaily(String email) {
        this.email1 = email;
        this.awesomeDeals.subscribeDaily();
    }

    /**
     * This subscribes the incoming email to hourly subscriptions.
     * It assigns the email to the class level variable email2
     * And it calls the object being observed subscribe hourly method so a property change event can be fired off
     * @param email
     */
    public void subscribeHourly(String email){
        this.email2 = email;
        this.awesomeDeals.subscribeHourly();
    }

    /**
     * This method violates single responsibility.
     * It first checks the incoming email to see if it exists as email2.
     * If email2 is null or doesn't match the passed in email
     * Then the message Email: the email Does not exist.
     * If the email exists then this email2 is set to null and this email1 is checked.
     * If both class level emails are null then the remove property change listener is called
     * Otherwise email2 is set to null and the message Removed and the email are printed.
     * @param email
     */
    public void unsubscribeHourly(String email) {
        if (email != null && this.email2.equals(email)) {
            this.email2 = null;
            if (this.email1 == null) {
                this.awesomeDeals.removePropertyChangeListener(this);
            }
            else{
                System.out.printf("Removed %s \n", email);
            }
        }
        else{
            System.out.printf("Email: %s Does Not exist\n", email);
        }
    }

    /**
     * This method violates single responsibility.
     * It first checks the incoming email to see if it exists as email1.
     * If email1 is null or doesn't match the passed in email
     * Then the message Email: the email Does not exist.
     * If the email exists then this email1 is set to null and this email2 is checked.
     * If both class level emails are null then the remove property change listener is called
     * Otherwise email1 is set to null and the message Removed and the email are printed.
     * @param email
     */
    public void unsubscribeDaily(String email){
        if(email != null && this.email1.equals(email)) {
            this.email1 = null;
            if (this.email2 == null){
                this.awesomeDeals.removePropertyChangeListener(this);
            }
            else{
                System.out.printf("Removed %s", email);
            }
        }
        else{
            System.out.printf("Email: %s Does Not exist", email);
        }
    }

    /**
     * The property change event allows the observer to update what was changed.
     * For this method look at the sample output and match it to the best of your ability.
     * After some if/if else statements every thing is printed to the screen
     * @param event
     */
    @Override
    public void propertyChange(PropertyChangeEvent event){
        String propertyName = event.getPropertyName();
        Object oldValue = event.getOldValue();
        Object newValue = event.getNewValue();

        System.out.print("EmailDeals - " + propertyName + ": [");
        if (oldValue != null) {
            System.out.print("old -> " + oldValue + " ] | [");
        }
        System.out.println("new -> " + newValue + "]");
    }
}


//        if (event.getPropertyName().equals("New Daily") && event.getOldValue() != null ) {
//            System.out.printf("%s - %s: [old -> %s] | [new -> %s]\n", this.getClass().getSimpleName(), event.getPropertyName(), event.getOldValue(), event.getNewValue());
//        }
//        if (event.getPropertyName().equals("New Daily") && event.getOldValue() == null ){
//            System.out.printf("%s - %s: [old -> Daily Day 2] | [new -> %s]\n", this.getClass().getSimpleName(), event.getPropertyName(), event.getNewValue());
//        }



//        String propertyName = event.getPropertyName();
//        Object oldValue = event.getOldValue();
//        Object newValue = event.getNewValue();
//
//        if ("Daily Deal".equals(propertyName)) {
//            System.out.println("EmailDeals - New Daily:  [old -> " + oldValue + "] | [new -> " + newValue + "]");
//        }
//        if("Hourly Deal".equals(propertyName)){
//            System.out.println("EmailDeals - New Hourly:  [old -> " + oldValue + "] | [new -> " + newValue + "]");
//        }
//        if("Subscribed Hourly".equals(propertyName)){
//            System.out.println("EmailDeals - New Hourly: [new -> " + this.awesomeDeals.getHourly() + "]");
//        }
//        if("Subscribed Daily".equals(propertyName)){
//            System.out.println("EmailDeals - New Daily: [new -> " + this.awesomeDeals.getDaily() + "]");
//        }

//        System.out.println("EmailDeals - " + event.getPropertyName() + ": [" + (event.getOldValue() == null ? "" : "old -> " + event.getOldValue() + " ] | [") + "new -> " + event.getNewValue() + "]");