package cscd212classes.observers;

import cscd212classes.observable.AwesomeDeals;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class TextDeals implements PropertyChangeListener {
    private String phoneNumber;
    private AwesomeDeals awesomeDeals;

    /**
     * This EVC receives the object being observed.
     * It sets the class level variable for AwesomeDeals
     * And it add this class to the property change listener
     * @param awesomeDeals
     */
    public TextDeals(AwesomeDeals awesomeDeals) {
        this.awesomeDeals = awesomeDeals;
        this.awesomeDeals.addPropertyChangeListener(this);
    }

    /**
     * This method receives the phone number that is added to the object being observed.
     * The phone number is only set if the class level variable is null.
     * Once the phone number is set the subscribe daily method from the class being observed is called.
     * @param phoneNumber
     */
    public void subscribeDaily(String phoneNumber) {
        if (phoneNumber == null) {
            this.phoneNumber = phoneNumber;
        }
        this.awesomeDeals.subscribeDaily();

    }

    /**
     * This method receives the phone number that is added to the object being observed.
     * The phone number is only set if the class level variable is null.
     * Once the phone number is set the subscribe hourly method from the class being observed is called.
     * @param phoneNumber
     */
    public void subscribeHourly(String phoneNumber) {
        if (phoneNumber == null) {
            this.phoneNumber = phoneNumber;
        }
        this.awesomeDeals.subscribeHourly();

    }

    /**
     * This method violates single responsibility.
     * It first checks the incoming phone number to see if it exists.
     * If phone number is null or doesn't match the passed in phone number
     * Then the message Phone Number: the phone number Does not exist.
     * If the phone number exists then this phone number is set to null and the remove property change listener is called.
     * Finally, the message Removed and the phone number are printed.
     * @param phoneNumber
     */
    public void unsubscribeAll(String phoneNumber) {
        if (phoneNumber == null || !phoneNumber.equals(phoneNumber)) {
            System.out.printf("Phone number: %s Does not exist\n", phoneNumber);
        }

        this.phoneNumber = null;
        this.awesomeDeals.removePropertyChangeListener(this);
        System.out.printf("Removed %s\n", phoneNumber);
    }

    /**
     * The property change event allows the observer to update what was changed.
     * For this method look at the sample output and match it to the best of your ability.
     * After some if/if else statements every thing is printed to the screen
     * @param event
     */
    @Override
    public void propertyChange(PropertyChangeEvent event) {
        String propertyName = event.getPropertyName();
        Object oldValue = event.getOldValue();
        Object newValue = event.getNewValue();

        System.out.print("TextDeals - " + propertyName + ": [");
        if (oldValue != null) {
            System.out.print("old -> " + oldValue + " ] | [");
        }
        System.out.println("new -> " + newValue + "]");
    }
}





// Code ive tried for the stupid propertyChange method

//        if (event.getPropertyName().equals("New Daily") && event.getOldValue() != null ) {
//            System.out.printf("%s - %s: [old -> %s] | [new -> %s]\n", this.getClass().getSimpleName(), event.getPropertyName(), event.getOldValue(), event.getNewValue());
//        }
//        if (event.getPropertyName().equals("New Daily") && event.getOldValue() == null ){
//            System.out.printf("%s - %s: [old -> Daily Day 2] | [new -> %s]\n", this.getClass().getSimpleName(), event.getPropertyName(), event.getNewValue());
//        }


//        if ("dailyDeal".equals(propertyName)) {
//            System.out.println("TextDeals - New Daily:  [old -> " + oldValue + "] | [new -> " + newValue + "]");
//        } else if("hourlyDeal".equals(propertyName)) {
//            System.out.println("TextDeals - New Hourly:  [old -> " + oldValue + "] | [new -> " + newValue + "]");
//        } else {
//            System.out.println("TextDeals - " + propertyName + ":   [old -> " + oldValue + "] | [new -> " + newValue + "]");
//        }


//        String propertyName = event.getPropertyName();
//        Object oldValue = event.getOldValue();
//        Object newValue = event.getNewValue();
//        if ("Daily Deal".equals(propertyName)) {
//            System.out.println("TextDeals - New Daily:  [old -> " + oldValue + "] | [new -> " + newValue + "]");
//        }
//        if("Hourly Deal".equals(propertyName)){
//            System.out.println("TextDeals - New Hourly:  [old -> " + oldValue + "] | [new -> " + newValue + "]");
//        }
//        if("Subscribed Hourly".equals(propertyName)){
//            System.out.println("TextDeals - New Hourly: [new -> " + this.awesomeDeals.getHourly() + "]");
//        }
//        if("Subscribed Daily".equals(propertyName)){
//            System.out.println("TextDeals - New Daily: [new -> " + this.awesomeDeals.getDaily() + "]");
//        }

//        if (event.getPropertyName().equals("New Hourly") && event.getOldValue() != null) {
//            System.out.printf("%s - %s: [old -> Hourly Deal %s] | [new -> Hourly Deal %s]\n", this.getClass().getSimpleName(), event.getPropertyName(), event.getOldValue(), event.getNewValue());
//        }
//        if (event.getOldValue() == null) {
//            System.out.printf("%s - %s: [old -> Hourly Deal %s] | [new -> Hourly Deal %s]\n", this.getClass().getSimpleName(), event.getPropertyName(), event.getOldValue(), event.getNewValue());
//        }

//        System.out.println("TextDeals - " + event.getPropertyName() + ": [" + (event.getOldValue() == null ? "" : "old -> " + event.getOldValue() + " ] | [") + "new -> " + event.getNewValue() + "]");
//        System.out.println("TextDeals - " + propertyName + ":  [old -> " + oldValue + "] | [new -> " + newValue + "]");