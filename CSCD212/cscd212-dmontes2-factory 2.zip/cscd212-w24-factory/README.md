# README

Make a Factory

Use the [docs (./docs/index.html)](./docs/index.html)

A example [main](./src/cscd212lab6/CSCD212Lab6.java) is given with a [sample output](./sample_output.pdf) for the example [main](./src/cscd212lab6/CSCD212Lab6.java) 

TA will make a announcement on canvas when the Tests are available on GitHub actions

# REMOVE THE CLASS FROM COLLABORATORS



