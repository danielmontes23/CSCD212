package cscd212classes.lifeform;

public class Human extends LifeForm{

    /**
     * Human constructor calling super
     * @param name
     * @param currentLifePoints
     */
    public Human(String name, int currentLifePoints){
        super(name, currentLifePoints);
    }
}
