package cscd212classes.lifeform;

public abstract class LifeForm {

    private final String name;
    protected int currentLifePoints;

    /**
     * The constructor to create a LifeForm object which sets the name and currentLifePoints.
     * @param name
     * @param currentLifePoints
     * Throws if name is null or empty or currentLifePoints is <= 0
     */
    public LifeForm(String name, int currentLifePoints){
        if(name == null || name.isEmpty() || currentLifePoints <= 0)
            throw new IllegalArgumentException("Bad parameters. (LifeForm constructor)");
        this.name = name;
        this.currentLifePoints = currentLifePoints;
    }

    /**
     * @return currentLifePoints
     * throws if currentLifePoints is < 0
     */
    public int getCurrentLifePoints(){
        if(currentLifePoints < 0)
            throw new IllegalArgumentException("Bad Parameters getCurrentLifePoints");
        return currentLifePoints;
    }

    /**
     * Sets this LifeForm's currentLifePoints to the passed parameter.
    * @return currentLifePoints
    * throws if currentLifePoints is < 0
    */
    public void setCurrentLifePoints(int currentLifePoints){
        if (currentLifePoints < 0)
            throw new IllegalArgumentException("Life points less than 0.");
        this.currentLifePoints = currentLifePoints;
    }

    /**
     * @returns LifeForm's name
     */
    public String getName(){
        return name;
    }

    /**
     * @returns name and currentLifePoints as a string
     * String in the format {name} + " has " + {currentLifePoints} + " life points"
     */
    public String toString(){
        return "{" + name + "}" + " has " + "{" + currentLifePoints + "}";
    }
}
