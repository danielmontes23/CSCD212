package cscd212classes.lifeform;

public class HalfOrc extends LifeForm{

    /**
     * HalfOrc constructor calling super
     * @param name
     * @param currentLifePoints
     */
    public HalfOrc(String name, int currentLifePoints){
        super(name, currentLifePoints);
    }
}
