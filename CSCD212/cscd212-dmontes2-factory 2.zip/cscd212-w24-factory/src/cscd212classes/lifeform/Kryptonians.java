package cscd212classes.lifeform;

public class Kryptonians extends LifeForm{

    /**
     * Kryptonians constructor calling super
     * @param name
     * @param currentLifePoints
     */
    public Kryptonians(String name, int currentLifePoints){
        super(name, currentLifePoints);
    }
}
