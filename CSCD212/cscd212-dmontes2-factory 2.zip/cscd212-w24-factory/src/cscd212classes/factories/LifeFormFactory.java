package cscd212classes.factories;

import cscd212classes.lifeform.HalfOrc;
import cscd212classes.lifeform.Human;
import cscd212classes.lifeform.LifeForm;
import cscd212classes.lifeform.Martian;
import cscd212enums.LifeFormType;

public class LifeFormFactory {

    /**
     * Constructor
     */
    public LifeFormFactory(){

    }

    /**
     * This method creates the appropriate life form by calling the appropriate constructor
     * Then passing the correct parameters.
     * It checks the life form type and depending on which life form type creates a new LifeForm object.
     * HINT: this is a series of ifs or if/elses or switch case what should be the default life form
     * @param lifeFormType
     * @param name
     * @param currentLifePoints
     * @return
     */
    public static LifeForm getLifeForm(LifeFormType lifeFormType, String name, int currentLifePoints){
        LifeForm lifeForm = null;
        if (lifeFormType == LifeFormType.HALF_ORC) {
            lifeForm = new HalfOrc(name, currentLifePoints);
        } else if (lifeFormType == LifeFormType.MARTIAN) {
            lifeForm = new Martian(name, currentLifePoints);
        } else if (lifeFormType == LifeFormType.HUMAN) {
            lifeForm = new Human(name, currentLifePoints);
        }
        return lifeForm;
    }

    /**
     * This method creates the appropriate life form by calling the other get life form method
     * Then passing it the default values for the name and the current life points
     * @param lifeFormType
     * @return
     */
    public static LifeForm getLifeForm(LifeFormType lifeFormType){
        String defaultName = "DefaultName";
        int defaultLifePoints = 100;

        return getLifeForm(lifeFormType, defaultName, defaultLifePoints);
    }
}
