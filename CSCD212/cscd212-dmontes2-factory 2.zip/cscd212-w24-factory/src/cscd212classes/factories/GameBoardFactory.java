package cscd212classes.factories;

import cscd212classes.boards.EarthBoard;
import cscd212classes.boards.FantasyBoard;
import cscd212classes.boards.GameBoard;
import cscd212classes.boards.MarsBoard;
import cscd212enums.BoardTheme;
import cscd212enums.DifficultyLevel;


public class GameBoardFactory {
    /**
     * Constructor
     */
    public GameBoardFactory(){

    }

    /**
     * This method builds the appropriate game board by checking the enumerated type
     * Then calling the appropriate game board constructor
     * HINT: this is a series of ifs or if/elses or switch case what should be the default
     * @param levelTheme
     * @param difficultyLevel
     * @return
     */
    public static GameBoard getGameBoard(BoardTheme levelTheme, DifficultyLevel difficultyLevel) {
        if(levelTheme == null || difficultyLevel == null){
            throw new IllegalArgumentException("Bad parameters in getGameBoard.");
        }
        else if(levelTheme == BoardTheme.EARTH){
            return new EarthBoard(difficultyLevel);
        }
        else if(levelTheme == BoardTheme.MARS){
            return new MarsBoard(difficultyLevel);
        }
        else if(levelTheme == BoardTheme.FANTASY){
            return new FantasyBoard(difficultyLevel);
        }
        return null;
    }
}
