package cscd212classes.boards;

import cscd212classes.factories.LifeFormFactory;
import cscd212classes.lifeform.HalfOrc;
import cscd212classes.lifeform.Human;
import cscd212classes.lifeform.Kryptonians;
import cscd212enums.DifficultyLevel;
import cscd212enums.LifeFormType;

import static cscd212enums.LifeFormType.*;

public class FantasyBoard extends GameBoard{

    /**
     * This explicit value constructor simply calls the constructor in GameBoard
     * @param difficultyLevel
     */
    public FantasyBoard(DifficultyLevel difficultyLevel){
        super(difficultyLevel);
    }

    /**
     * For FantasyBoard this overridden method sets the player to a HALF_ORC The enemies are
     * KRYPTON with default life points and name
     * KRYPTON named "Uzguk" with 80 life points
     * HUMAN named "Dave" with 110 life points
     */
    @Override
    protected void createLifeForms(){
        this.player = LifeFormFactory.getLifeForm(HALF_ORC);
        enemyLifeForms.add(LifeFormFactory.getLifeForm(KRYPTON));
        enemyLifeForms.add(LifeFormFactory.getLifeForm(KRYPTON, "Uzguk", 80));
        enemyLifeForms.add(LifeFormFactory.getLifeForm(HUMAN, "Dave", 110));
    }
}


        //player = new HalfOrc("HALF_ORC", 100);
        //Kryptonians enemy1 = new Kryptonians("Default name",);
        //Kryptonians enemy2 = new Kryptonians("Uzquk", 80);
        //Human enemy3 = new Human("Dave", 110);
        //enemyLifeForms.add(enemy1);
        //enemyLifeForms.add(enemy2);
        //enemyLifeForms.add(enemy3);