package cscd212classes.boards;

import cscd212classes.lifeform.LifeForm;
import cscd212enums.DifficultyLevel;

import java.util.ArrayList;

public abstract class GameBoard {
    protected ArrayList<LifeForm> enemyLifeForms;
    protected LifeForm player;

    /**
     * The explicit value constructor that recieves a difficulty level and creates the game board by first creating an empty arraylist
     * Then creating the life forms by calling the appropriate subclass createLifeForms method
     * Next adjusting the difficulty level
     * Finally trimming the enemy life forms arraylist to the proper size
     * @param difficultyLevel
     */
    public GameBoard(DifficultyLevel difficultyLevel){
        enemyLifeForms = new ArrayList<>();
        createLifeForms();
        adjustForDifficulty(difficultyLevel);
    }

    /**
     * Returns the current player
     * @return player
     */
    public LifeForm getPlayer(){
        return player;
    }

    /**
     * The getEnemyLifeForms returns the ArrayList of LifeForms that represent the enemies
     * @return arrayList of enemies
     */
    public ArrayList<LifeForm> getEnemyLifeForms(){
        return enemyLifeForms;
    }

    /**
     * This abstract method is overridden in all the subclasses of GameBoard
     */
    protected abstract void createLifeForms();

    /**
     * This method adjusts the enemies life points based on the difficulty level of the game.
     * The more difficult the game is, the more life points are awarded to the enemies.
     * This method first grabs each enemy's life points.
     * Then multiplies those life points by the difficulty level modifier.
     * Finally, a cast is made (to an int) and individual enemy's life points are set.
     * @param difficultyLevel
     */
    protected void adjustForDifficulty(DifficultyLevel difficultyLevel){
        if (difficultyLevel == null) {
            throw new IllegalArgumentException("Difficulty level cannot be null.");
        }

        for (LifeForm enemy : enemyLifeForms) {
            if (enemy != null) {
                int currentLifePoints = enemy.getCurrentLifePoints();

                double modifier = difficultyLevel.getModifier();
                int adjustedLifePoints = (int) (currentLifePoints * modifier);

                enemy.setCurrentLifePoints(adjustedLifePoints);
            } else {
                System.out.println("Enemy is null.");
            }
        }
    }
}

