package cscd212classes.boards;

import cscd212classes.factories.LifeFormFactory;
import cscd212classes.lifeform.Human;
import cscd212classes.lifeform.Martian;
import cscd212enums.DifficultyLevel;
import cscd212enums.LifeFormType;

import static cscd212enums.LifeFormType.HUMAN;
import static cscd212enums.LifeFormType.MARTIAN;

public class MarsBoard extends GameBoard{

    /**
     * This explicit value constructor simply calls the constructor in GameBoard
     * @param difficultyLevel
     */
    public MarsBoard(DifficultyLevel difficultyLevel){
        super(difficultyLevel);
    }

    /**
     * For BeachBoard this overridden method sets the player to a HUMAN The enemies are
     * MARTIAN with default life points and name
     * MARTIAN named Steve with 50 life points
     * HUMAN named Evil Carl with 110 life points
     * HUMAN named Carl with 100 life points
     */
    @Override
    protected void createLifeForms(){
        this.player = LifeFormFactory.getLifeForm(HUMAN);
        enemyLifeForms.add(LifeFormFactory.getLifeForm(MARTIAN));
        enemyLifeForms.add(LifeFormFactory.getLifeForm(MARTIAN, "Steve", 50));
        enemyLifeForms.add(LifeFormFactory.getLifeForm(HUMAN, "Evil Carl", 110));
        enemyLifeForms.add(LifeFormFactory.getLifeForm(HUMAN, "Carl", 100));
    }
}
