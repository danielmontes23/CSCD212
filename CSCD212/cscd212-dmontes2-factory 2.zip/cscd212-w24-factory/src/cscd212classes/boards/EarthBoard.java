package cscd212classes.boards;

import cscd212classes.factories.LifeFormFactory;
import cscd212classes.lifeform.Human;
import cscd212classes.lifeform.Martian;
import cscd212enums.DifficultyLevel;
import cscd212enums.LifeFormType;
import cscd212enums.DifficultyLevel;
import cscd212enums.BoardTheme;

import static cscd212enums.LifeFormType.HUMAN;
import static cscd212enums.LifeFormType.MARTIAN;


public class EarthBoard extends GameBoard{

    /**
     * This explicit value constructor simply calls the constructor in GameBoard
     * @param difficultyLevel
     */
    public EarthBoard(DifficultyLevel difficultyLevel){
        super(difficultyLevel);
    }

    /**
     * For EarthBoard this overridden method sets the player to a MARTIAN The enemies are
     * HUMAN named Dave with 110 life points
     * HUMAN with default life points and name
     */
    protected void createLifeForms(){
        this.player = LifeFormFactory.getLifeForm(MARTIAN);
        enemyLifeForms.add(LifeFormFactory.getLifeForm(HUMAN, "Dave", 110));
        enemyLifeForms.add(LifeFormFactory.getLifeForm(HUMAN));
    }
}

            //player = new Martian("Martian", 100);
            //Human enemy1 = new Human("Dave", 110);
            //Human enemy2 = new Human("Default Name", 120);
            //enemyLifeForms.add(enemy2);
