package cscd212enums;

public enum LifeFormType {
    HALF_ORC("Gruumsh", 200),

    HUMAN("Hugh Mann", 100),
    KRYPTON("Kal-El", 300),
    MARTIAN("Marvin", 120);

    private final String name;
    private final int currentLifePoints;

    /**
     * @param name
     * @param currentLifePoints
     * throws if parameters are null, empty, or less than or equal to 0
     */
    private LifeFormType(String name, int currentLifePoints) {
        if (name == null || name.isEmpty() || currentLifePoints <= 0) {
            throw new IllegalArgumentException("Invalid name or life points");
        }
        this.name = name;
        this.currentLifePoints = currentLifePoints;
    }

    /**
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * @return currentLifePoints
     */
    public int getCurrentLifePoints() {
        return currentLifePoints;
    }
}
