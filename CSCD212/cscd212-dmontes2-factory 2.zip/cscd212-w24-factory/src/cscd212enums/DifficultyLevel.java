package cscd212enums;

public enum DifficultyLevel {
    EASY(0.7),
    HARD(1.5),
    INSANE(2),
    NORMAL(1);

    private double difficultyModifier;

    /**
     * Constructor
     * @param difficultyModifier
     * throws if difficultyModifier is <= 0
     */
    private DifficultyLevel(double difficultyModifier){
        if(difficultyModifier <= 0)
            throw new IllegalArgumentException("Bad parameters. (DifficultyLevel)");
        this.difficultyModifier = difficultyModifier;
    }

    /**
     *
     * @return difficultyModifier
     */
    public double getModifier(){
        return difficultyModifier;
    }
}
