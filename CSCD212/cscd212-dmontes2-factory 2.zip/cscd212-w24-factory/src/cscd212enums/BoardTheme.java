package cscd212enums;

public enum BoardTheme{
    EARTH,
    FANTASY,
    MARS;

    private BoardTheme(){
    }
}
