import cscd212classes.boards.GameBoard;
import cscd212classes.boards.FantasyBoard;
import cscd212classes.boards.MarsBoard;
import cscd212classes.boards.EarthBoard;

import cscd212classes.factories.GameBoardFactory;
import cscd212classes.factories.LifeFormFactory;

import cscd212classes.lifeform.LifeForm;
import cscd212classes.lifeform.Human;
import cscd212classes.lifeform.Martian;
import cscd212classes.lifeform.Kryptonians;
import cscd212classes.lifeform.HalfOrc;

import cscd212enums.DifficultyLevel;
import cscd212enums.LifeFormType;
import cscd212enums.BoardTheme;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.assertNotNull;

public class tester {

    //@Test
    //@DisplayName("")
    //public void difficultlyLevelConstructor() {
    //    DifficultyLevel validLevel = new DifficultyLevel();
    //    assertNotNull(validLevel);
    //}

    @Test
    @DisplayName("Earth and Easy")
    public void easyEarth() {
        BoardTheme levelTheme = BoardTheme.EARTH;
        DifficultyLevel difficultyLevel = DifficultyLevel.EASY;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Fantasy and Easy")
    public void easyFantasy() {
        BoardTheme levelTheme = BoardTheme.FANTASY;
        DifficultyLevel difficultyLevel = DifficultyLevel.EASY;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Mars and Easy")
    public void easyMars() {
        BoardTheme levelTheme = BoardTheme.MARS;
        DifficultyLevel difficultyLevel = DifficultyLevel.EASY;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Earth and hard")
    public void hardEarth() {
        BoardTheme levelTheme = BoardTheme.EARTH;
        DifficultyLevel difficultyLevel = DifficultyLevel.HARD;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Fantasy and hard")
    public void hardFantasy() {
        BoardTheme levelTheme = BoardTheme.FANTASY;
        DifficultyLevel difficultyLevel = DifficultyLevel.HARD;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Mars and hard")
    public void hardMars() {
        BoardTheme levelTheme = BoardTheme.MARS;
        DifficultyLevel difficultyLevel = DifficultyLevel.HARD;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Earth and insane")
    public void insaneEarth() {
        BoardTheme levelTheme = BoardTheme.EARTH;
        DifficultyLevel difficultyLevel = DifficultyLevel.INSANE;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Mars and insane")
    public void insaneMars() {
        BoardTheme levelTheme = BoardTheme.MARS;
        DifficultyLevel difficultyLevel = DifficultyLevel.INSANE;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Fantasy and insane")
    public void insaneFantasy() {
        BoardTheme levelTheme = BoardTheme.FANTASY;
        DifficultyLevel difficultyLevel = DifficultyLevel.INSANE;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Earth and normal")
    public void normalEarth() {
        BoardTheme levelTheme = BoardTheme.EARTH;
        DifficultyLevel difficultyLevel = DifficultyLevel.NORMAL;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Mars and normal")
    public void normalMars() {
        BoardTheme levelTheme = BoardTheme.MARS;
        DifficultyLevel difficultyLevel = DifficultyLevel.NORMAL;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }

    @Test
    @DisplayName("Fantasy and normal")
    public void normalFantasy() {
        BoardTheme levelTheme = BoardTheme.FANTASY;
        DifficultyLevel difficultyLevel = DifficultyLevel.NORMAL;

        GameBoard gameBoard = GameBoardFactory.getGameBoard(levelTheme, difficultyLevel);
        assertNotNull(gameBoard);
    }
}
