# cscd212-f23-lab2
CSCD 212 Strategy Pattern
