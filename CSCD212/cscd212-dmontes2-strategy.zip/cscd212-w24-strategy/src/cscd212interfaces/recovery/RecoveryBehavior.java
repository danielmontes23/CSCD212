package cscd212interfaces.recovery;

public interface RecoveryBehavior {
    /**
     * The abstract method calculateRecovery.
     * Parameters:
     * currentLifePoints - - the int used in the calculation of recovered life points
     * Returns:
     * int Representing the total life points recovered NOTE Modifier is public abstract
     * @param currentLifePoints
     * @return
     */
    public abstract int calculateRecovery(int currentLifePoints);
}
