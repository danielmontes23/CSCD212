package cscd212interfaces.alienknowledge;

public interface AlienBehavior {
    public abstract double upArmor();
}
