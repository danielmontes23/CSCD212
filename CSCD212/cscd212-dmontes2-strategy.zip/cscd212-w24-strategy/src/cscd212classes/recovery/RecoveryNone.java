package cscd212classes.recovery;

import cscd212interfaces.recovery.RecoveryBehavior;

public class RecoveryNone extends Object implements RecoveryBehavior {

    /**
     *
     */
    public RecoveryNone(){
    }

    /**
     * No recovery behavior means this implementation of calculateRecovery will always return 0.
     * Specified by:
     * calculateRecovery in interface RecoveryBehavior
     * Parameters:
     * currentLifePoints - - the int used in the calculation of recovered life points
     * Returns:
     * int - the total number of life points recovered
     * @param currentLifePoints
     * @return
     */
    public int calculateRecovery(int currentLifePoints){
        return 0;
    }
}
