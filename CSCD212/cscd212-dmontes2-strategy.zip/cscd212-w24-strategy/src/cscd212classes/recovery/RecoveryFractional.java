package cscd212classes.recovery;

import cscd212interfaces.recovery.RecoveryBehavior;

public class RecoveryFractional extends Object implements RecoveryBehavior {
    private final int BASE_RECOVERY;
    private double recoveryPercent;

    /**
     * The constructor to create a RecoveryFractional object which sets this recoveryPercent and BASE_RECOVERY to the passed parameters.
     * Parameters:
     * recoveryPercent - - the double which represents the percentage of total life points to be returned when calculating recovery.
     * baseRecovery - - the int which represents the minimum life points recovered per calculation NOTE recovery percentages are passed in as doubles, such as 0.33 for 33%
     * @param recoveryPercent
     * @param baseRecovery
     */
    public RecoveryFractional(double recoveryPercent, int baseRecovery){
        this.recoveryPercent = recoveryPercent;
        this.BASE_RECOVERY = baseRecovery;
    }

    /**
     * The constructor to create a RecoveryFractional object which sets this recoveryPercent to the passed parameter and then sets the BASE_RECOVERY to a default of 10.
     * Parameters:
     * recoveryPercent - - the double which represents the percentage of total life points to be returned when calculating recovery. NOTE recovery percentages are passed in as doubles, such as 0.33 for 33%
     * @param recoveryPercent
     */
    public RecoveryFractional(double recoveryPercent){
        this(recoveryPercent, 10);
    }

    /**
     * Recovery amount is calculated by multiplying currentLifePoints by this Object's recoveryPercent and casting the result to an int. If the result is less than this Object's BASE_RECOVERY, BASE_RECOVERY is returned. Otherwise, the calculated amount is returned.
     * Specified by:
     * calculateRecovery in interface RecoveryBehavior
     * Parameters:
     * currentLifePoints - - the int used in the calculation of recovered life points
     * Returns:
     * int - the total number of life points recovered
     * @param currentLifePoints
     * @return
     */
    public int calculateRecovery(int currentLifePoints) {
        int sum = (int)(currentLifePoints * this.recoveryPercent);
        if(sum < this.BASE_RECOVERY){
            return BASE_RECOVERY;
        }
        return sum;
    }
}
