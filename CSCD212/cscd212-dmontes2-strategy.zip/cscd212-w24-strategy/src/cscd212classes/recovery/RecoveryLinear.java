package cscd212classes.recovery;

import cscd212interfaces.recovery.RecoveryBehavior;

public class RecoveryLinear extends Object implements RecoveryBehavior {

    private int recoveryStep;

    /**
     * The constructor to create a RecoveryLinear object which sets this recoveryStep to the passed parameter.
     *      * Parameters:
     *      * recoveryStep - - the int which represents the set number of life points recovered per calculation
     *      * Throws:
     *      * IllegalArgumentException - If recoveryStep is ≤ 0
     * @param recoveryStep
     */
    public RecoveryLinear(int recoveryStep){
        if (recoveryStep <= 0) {
            throw new IllegalArgumentException("Recovery step must be greater than zero");
        }
        this.recoveryStep = recoveryStep;
    }


    /**
     * Recovery amount is always the recoveryStep, therefore calculateRecovery simply returns this recoveryStep without any calculation.
     *      * Specified by:
     *      * calculateRecovery in interface RecoveryBehavior
     *      * Parameters:
     *      * currentLifePoints - - the int used in the calculation of recovered life points
     *      * Returns:
     *      * int - the total number of life points recovered
     * @param currentLifePoints
     * @return
     */

    public int calculateRecovery(int currentLifePoints){
        currentLifePoints = recoveryStep;
        return currentLifePoints;
    }
}
