package cscd212classes.lifeform;

public abstract class LifeForm extends Object{
    private String name;

    protected int currentLifePoints;
    protected final int MAX_LIFE_POINTS;

    /**
     * The constructor to create a LifeForm object which sets the name, currentLifePoints, and MAX_LIFE_POINTS.
     * Parameters:
     * name - - this LifeForm's name
     * currentLifePoints - - this LifeForm's current life points
     * maxLifePoints - - this LifeForm's maximum life points
     * Throws:
     * IllegalArgumentException - - If name is null or empty or if currentLifePoints is ≤ 0 or if maxLifePoints ≤ 0 or if currentLifePoints > maxLifePoints
     * @param name
     * @param currentLifePoints
     * @param maxLifePoints
     */
    public LifeForm(String name, int currentLifePoints, int maxLifePoints){
        if(name == null || name.isEmpty() || currentLifePoints <= 0 || maxLifePoints <= 0 || currentLifePoints > maxLifePoints)
            throw new IllegalArgumentException("Bad Params in LifeForm Constructor");
        this.MAX_LIFE_POINTS = maxLifePoints;
        this.name = name;
        this.currentLifePoints = currentLifePoints;
    }

    /**
     * The constructor to create a LifeForm object which sets the name and currentLifePoints and sets MAX_LIFE_POINTS to the default of 100.
     * Parameters:
     * name - - this LifeForm's name
     * currentLifePoints - - this LifeForm's current life points
     * Throws:
     * IllegalArgumentException - - If name is null or empty or if currentLifePoints is ≤ 0
     * @param name
     * @param currentLifePoints
     */
    public LifeForm(String name, int currentLifePoints){
        if(name == null || name.isEmpty() || currentLifePoints <= 0)
            throw new IllegalArgumentException("Bad param.");
        this.name = name;
        this.currentLifePoints = currentLifePoints;
        this.MAX_LIFE_POINTS = 100;
    }

    /**
     * Returns this LifeForm's current life points.
     * Returns:
     * int - this LifeForm's current life points
     * @return
     */
    public int getLifePoints(){
        return currentLifePoints;
    }

    /**
     * Returns this LifeForm's name.
     * Returns:
     * String - this LifeForm's name
     * @return
     */
    public String getName(){
        return name;
    }

    /**
     * The takeHit method verifies the incoming damage is greater than 0 before reducing the current life points by that amount. If the damage is greater than or equal to the life form's current life points, then the life points will be reduced to 0.
     * Parameters:
     * damage - - int representing the damage being applied to this LifeForm
     * Throws:
     * IllegalArgumentException - - if the incoming damage is ≤ 0 NOTE it is not possible to have negative life points
     * @param damage
     */
    public void takeHit(int damage){
        if (damage <= 0) {
            throw new IllegalArgumentException("Bad Params in takeHit");
        }
        if(damage < currentLifePoints){
            currentLifePoints -= damage;
        } else {
            currentLifePoints = 0;
        }
    }

    /**
     * Returns a representation of the name and current life points as a String.
     * Overrides:
     * toString in class Object
     * Returns:
     * String in the format {name} + " has " + {currentLifePoints} + " life points"
     * @return
     */
    @Override
    public String toString(){
        return getName() + " has " + currentLifePoints + " life points" ;
    }
}
