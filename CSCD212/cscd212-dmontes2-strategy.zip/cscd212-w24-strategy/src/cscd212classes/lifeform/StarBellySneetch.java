package cscd212classes.lifeform;

import cscd212interfaces.recovery.RecoveryBehavior;

public class StarBellySneetch extends Alien{

    /**
     * The constructor to create a StarBellySneetch object which delegates the assignment of parameters to the parent constructor.
     * Parameters:
     * name - - this StarBellySneetch's name
     * currentLifePoints - - this StarBellySneetch's current life points
     * maxLifePoints - - this StarBellySneetch's maximum life points
     * recovery - - this StarBellySneetch's current RecoveryBehavior
     * @param name
     * @param currentLifePoints
     * @param maxLifePoints
     * @param recovery
     */
    public StarBellySneetch(String name, int currentLifePoints, int maxLifePoints, RecoveryBehavior recovery){
        super(name, currentLifePoints, maxLifePoints, recovery);
    }

    /**
     * The constructor to create a StarBellySneetch object which delegates the assignment of parameters and setting of default maxLifePoints and RecoveryBehavior to the parent constructor.
     * Parameters:
     * name - - this Martian's name
     * currentLifePoints - - this Martian's current life points
     * @param name
     * @param currentLifePoints
     */
    public StarBellySneetch(String name, int currentLifePoints){
        super(name, currentLifePoints);
    }
}
