package cscd212classes.lifeform;

import cscd212classes.recovery.RecoveryNone;
import cscd212interfaces.recovery.RecoveryBehavior;

public abstract class Alien extends LifeForm{
    private RecoveryBehavior recovery;

    /**
     *
     * The constructor to create an Alien object which delegates the assignment of name, currentLifePoints, and maxLifePoints to the parent constructor and then sets this recovery to the passed parameter.
     * Parameters:
     * name - - this Alien's name
     * currentLifePoints - - this Alien's current life points
     * maxLifePoints - - this Alien's maximum life points
     * recovery - - this Alien's current RecoveryBehavior
     * Throws:
     * IllegalArgumentException - If recovery is null
     * @param name
     * @param currentLifePoints
     * @param maxLifePoints
     * @param recovery
     */
    public Alien(String name, int currentLifePoints, int maxLifePoints, RecoveryBehavior recovery){
        super(name, currentLifePoints, maxLifePoints);
        if (recovery == null) {
            throw new IllegalArgumentException("Bad Params in Alien Constructor");
        }
         this.recovery = recovery;
    }

    /**
     * The constructor to create an Alien object which delegates the assignment of name and currentLifePoints to the parent constructor and then sets recovery to the default of RecoveryNone.
     * Parameters:
     * name - - this Alien's name
     * currentLifePoints - - this Alien's current life points
     * @param name
     * @param currentLifePoints
     */
    public Alien(String name, int currentLifePoints){
        super(name, currentLifePoints);
        this.recovery = new RecoveryNone();
    }

    /**
     * Sets the Alien's current life points.
     * Parameters:
     * currentLifePoints - - this Alien's new life point value
     * Throws:
     * IllegalArgumentException - - If currentLifePoints is ≤ 0 or greater than MAX_LIFE_POINTS
     * @param currentLifePoints
     */
    public void setCurrentLifePoints(int currentLifePoints){
        if (currentLifePoints <= 0 || currentLifePoints > MAX_LIFE_POINTS) {
            throw new IllegalArgumentException("Bad Params in setCurrentLifePoints");
        }
        this.currentLifePoints = currentLifePoints;
    }

    /**
     * Sets the Alien's current recovery.
     * Parameters:
     * newRecovery - - this Alien's new RecoveryBehavior
     * Throws:
     * IllegalArgumentException - - If recovery is null
     * @param newRecovery
     */
    public void setRecoveryBehavior(RecoveryBehavior newRecovery){
        if (newRecovery == null) {
            throw new IllegalArgumentException("Recovery behavior cannot be null");
        }
        this.recovery = newRecovery;
    }

    /**
     * Returns the Alien's current recoveryBehavior.
     * Returns:
     * RecoveryBehavior this Alien's current aggregated RecoveryBehavior object
     * @return
     */
    public RecoveryBehavior getRecoveryBehavior(){
        return recovery;
    }

    /**
     * The recover method delegates the calculation of the recovery points to the aggregated recovery object and returns a String representing the points recovered. Life points cannot recover a LifeForm past their MAX_LIFE_POINTS.
     * Returns:
     * String in the format {name} + " has had " + {points recovered} + " recovery points added their current life points"
     * @return
     */
    public String recover(){
        int recoveredPoints = recovery.calculateRecovery(currentLifePoints);

        int newLifePoints = Math.min(currentLifePoints + recoveredPoints, MAX_LIFE_POINTS);

        int pointsAdded = newLifePoints - currentLifePoints;

        setCurrentLifePoints(newLifePoints);
        return getName() + " has had " + pointsAdded + " recovery points added their current life points";
    }

    /**
     * Returns a representation of the name and current life points as a String. Calls the parent's toString and appends " and has recovery mode of " + the Class simple name of the aggregated recovery object.
     * Overrides:
     * toString in class LifeForm
     * Returns:
     * String in the format {super toString} + " and has recovery mode of " + {the Class simple name of the aggregated recovery object.}
     * @return
     */
    @Override
    public String toString(){
        return super.toString() + " and has recovery mode of " + recovery.getClass().getSimpleName();
    }
}
