package cscd212classes.lifeform;

import cscd212interfaces.recovery.RecoveryBehavior;

public class Martian extends Alien{

    /**
     * The constructor to create a Martian object which delegates the assignment of parameters and setting of default maxLifePoints and RecoveryBehavior to the parent constructor.
     * Parameters:
     * name - - this Martian's name
     * currentLifePoints - - this Martian's current life points
     * @param name
     * @param currentLifePoints
     */
    public Martian(String name, int currentLifePoints){
        super(name, currentLifePoints);
    }

    /**
     * The constructor to create a Martian object which delegates the assignment of parameters to the parent constructor.
     * Parameters:
     * name - - this Martian's name
     * currentLifePoints - - this Martian's current life points
     * maxLifePoints - - this Martian's maximum life points
     * recovery - - this Martian's current RecoveryBehavior
     * @param name
     * @param currentLifePoints
     * @param maxLifePoints
     * @param recovery
     */
    public Martian(String name, int currentLifePoints, int maxLifePoints, RecoveryBehavior recovery){
        super(name, currentLifePoints, maxLifePoints, recovery);
    }
}
