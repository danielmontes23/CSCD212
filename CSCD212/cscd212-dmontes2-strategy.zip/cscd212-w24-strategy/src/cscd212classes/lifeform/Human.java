package cscd212classes.lifeform;

import cscd212interfaces.alienknowledge.AlienBehavior;

public class Human extends LifeForm{
    private int armorPoints;
    private AlienBehavior behavior;

    /**
     * The constructor to create an Alien object which delegates the assignment of name, currentLifePoints, and maxLifePoints to the parent constructor and then sets armorPoints to the passed parameter. The value returned from the upArmor method for the appropriate behavior will be added to the passed in armorPoints
     * Parameters:
     * name - - this Human's name
     * currentLifePoints - - this Human's current life points
     * maxLifePoints - - this Human's maximum life points
     * armorPoints - - this Human's current armor points
     * behavior - - the alien behavior the human has
     * Throws:
     * IllegalArgumentException - - if armorPoints is < 0
     * @param name
     * @param currentLifePoints
     * @param maxLifePoints
     * @param armorPoints
     * @param behavior
     */
    public Human(String name, int currentLifePoints, int maxLifePoints, int armorPoints, AlienBehavior behavior){
        super(name, currentLifePoints, maxLifePoints);
        if(armorPoints < 0)
            throw new IllegalArgumentException("Bad Params in Human Constructor");
        this.armorPoints = armorPoints;
    }

    /**
     * The constructor to create an Alien object which delegates the assignment of name and currentLifePoints to the parent constructor and then sets armorPoints 100 + the value returned from upArmor method call for the appropriate behavior
     * Parameters:
     * name - - this Human's name
     * behavior - Representing the advantage for the human
     * currentLifePoints - - this Human's current life points
     * @param name
     * @param currentLifePoints
     * @param behavior
     */
    public Human(String name, int currentLifePoints, AlienBehavior behavior){
        super(name, currentLifePoints);
        this.behavior = behavior;
    }

    /**
     * Returns this Human's current armor points.
     * Returns:
     * int - this Human's current armor points
     * @return
     */
    public int getArmorPoints(){
        return armorPoints;
    }

    /**
     * Sets the Human's current armor points. The armor points passed in represent the base value. The appropriate behavior upArmor method is called and added to the base value;
     * Parameters:
     * armorPoints - Representing this Human's new armor point value as the starting base value. A call is made to the
     * Throws:
     * IllegalArgumentException - If armorPoints is < 0
     * @param armorPoints
     */
    public void setArmorPoints(int armorPoints){
        if(armorPoints < 0)
            throw new IllegalArgumentException("Bad Params in setArmorPoints");
        this.armorPoints = armorPoints;
    }

    /**
     * public void setAlienBehavior(AlienBehavior behavior)
     * This method sets the appropriate Alien Behavior
     * Parameters:
     * behavior - Representing the Alien Behavior advantage for the human
     * Throws:
     * IllegalArgumentException - if the Alien Behavior is null
     * @param behavior
     */
    public void setAlienBehavior(AlienBehavior behavior){
        if(behavior == null)
            throw new IllegalArgumentException("Bad Params in setArmorPoints");
        this.behavior = behavior;
    }

    /**
     * Calls the parent's toString and appends " and " + {armorPoints} + " armor points".
     * Overrides:
     * toString in class LifeForm
     * Returns:
     * String in the format {super toString} + " and " + {armorPoints} + " armor points"
     * @return
     */
    @Override
    public String toString(){
        return getName() + " has " + currentLifePoints + " life points and " + armorPoints + " armor points";
    }

    /**
     * When Humans with armorPoints take damage, the damage reduces the Human's armorPoints instead of reducing life points. The damage will reduce the armor points until the armor points value is 0. If a Human's armor points are reduced to 0, the application of the remaining damage is delegated to the parent's takeHit method.
     * Overrides:
     * takeHit in class LifeForm
     * Parameters:
     * damage - - the int representing damage being applied to this Human
     * Throws:
     * IllegalArgumentException - - if the incoming damage is ≤ 0 NOTE it is not possible to have negative armor points
     * @param damage
     */
    public void takeHit(int damage){
        if (damage <= 0) {
            throw new IllegalArgumentException("Bad Params in takeHit");
        }
        if(armorPoints > damage){
            armorPoints -= damage;
        } else {
            damage -= armorPoints;
            armorPoints = 0;
            if(damage > 0){
                super.takeHit(damage);
            }
        }
    }
}
