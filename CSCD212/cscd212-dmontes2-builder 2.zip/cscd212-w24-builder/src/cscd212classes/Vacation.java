package cscd212classes;

import cscd212accommodation.Accommodation;

import java.util.ArrayList;
import java.util.List;

public class Vacation{

    private List<Accommodation> accommodations;
    private List<String> events;
    private String name;

    /**
     * The EVC that takes the name of the vacation. This method sets the name, creates an ArrayList for the accommodations of default size, and creates and ArrayList of strings of default size for the events.
     * Parameters:
     * name - Representing the vacation name
     * Throws:
     * IllegalArgumentException - if name is null or blank. Message is Bad Params Vacation Constructor
     * @param name
     */
    public Vacation(String name){
        if(name == null || name.isBlank())
            throw new IllegalArgumentException("Bad Params Vacation Constructor");

        this.name = name;
        this.accommodations = new ArrayList<Accommodation>();
        this.events = new ArrayList<String>();
    }

    /**
     * Sets the accommodations
     * Parameters:
     * accommodations - Reresenting an ArrayList of accommodations. We blindly accept the shallow copy
     * Throws:
     * IllegalArgumentException - if accommodations is null. Message is Bad Params Vacation SetAccommodations
     * @param accommodations
     */
    public void setAccommodations(List<Accommodation> accommodations){
        if(accommodations == null)
            throw new IllegalArgumentException("Bad Params Vacation SetAccommodations");

        this.accommodations = accommodations;
    }

    /**
     * Sets the events
     * Parameters:
     * events - Reresenting an ArrayList of events.
     * Throws:
     * IllegalArgumentException - if events is null. Message is Bad Params Vacation SetEvents
     * @param events
     */
    public void setEvents(List<String> events){
        if(events == null)
            throw new IllegalArgumentException("Bad Params Vacation SetEvents");

        this.events = events;
    }

    /**
     * The toString returns ---- Your Vacation Details ----cr Location: the location cr Walks thru the arraylist of accommodations Walks thru the arraylist of events
     * Overrides:
     * toString in class Object
     * Returns:
     * String -- See Sample Run for the output
     * @return
     */
    @Override
    public String toString(){
        String res = "---- Your Vacation Details ----\nLocation: ";
        for(Accommodation d : this.accommodations){
            res += "\n" + d.toString();
        }
        for(String e : this.events){
            res += "\n" + e;
        }
        return res;
    }
}
