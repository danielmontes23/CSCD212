package cscd212classes;

import java.time.LocalDate;

public class Reservation{
    private LocalDate arrivalDate;
    private int nights;

    public Reservation(){
    }

    /**
     * This method sets the arrival date by calling a method inside LocalDate
     * Parameters:
     * year - Representing the year
     * month - Representing the month
     * day - Representingn the day
     * Throws:
     * IllegalArgumentException - if year is less than 2023, if month is less than 1 or greater than 12, if day is less than 1 or greater than 31. Message is Bad Params Reservation SetArrivalDate
     */
    public void setArrivalDate(int year, int month, int day){
        if(year < 2023 || month < 1 || month > 12 || day < 1 || day > 31)
            throw new IllegalArgumentException("bad params reservation setarrivaldate");

        this.arrivalDate = LocalDate.of(year, month, day);
    }

    /**
     * Returns the arrival date
     * Returns:
     * LocalDate Representing the arrival date
     * @return
     */
    public LocalDate getArrivalDate() {
        return arrivalDate;
    }

    /**
     * This method sets the number of nights
     * Parameters:
     * nights - Representing the number of nights
     * Throws:
     * IllegalArgumentException - if nights is less than 1. Message is Bad Params Reservation SetNights
     * @param nights
     */
    public void setNights(int nights){
        if(nights < 1)
            throw new IllegalArgumentException("Bad Params Reservation SetNights");

        this.nights = nights;
    }

    /**
     * The getNights method returns the number of nights reserved
     * Returns:
     * int Representing the number of nights for the reservation
     * @return
     */
    public int getNights(){
        return nights;
    }
}
