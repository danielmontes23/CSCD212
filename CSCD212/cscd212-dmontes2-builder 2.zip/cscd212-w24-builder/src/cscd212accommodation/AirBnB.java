package cscd212accommodation;

public class AirBnB extends Accommodation{
    private String address;

    /**
     * The EVC that is passed an Accommodation name and passes it to the super class
     * Parameters:
     * name - Representing the Accommodation name
     */
    public AirBnB(String name){
        super(name);
    }

    /**
     * GetAddress returns the address
     * Returns:
     * String Representing the address
     */
    public String getAddress(){
        return address;
    }

    /**
     * Sets the address
     * Parameters:
     * address - Representing the new address
     * Throws:
     * IllegalArgumentException - of the String is null or blank. Message is Bad Params AirBnB SetAddress
     */
    public void setAddress(String address){
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("Bad Params AirBnB SetAddress");
        }
        this.address = address;
    }

    /**
     * Returns the location
     * Specified by:
     * getLocation in class Accommodation
     * Returns:
     * String representing the current location
     */
    public String getLocation(){
        return "AirBnb at " + this.address;
    }
}
