package cscd212accommodation;

public class Campsite extends Accommodation{
    private int siteNumber;

    /**
     * The EVC that is passed an Accommodation name and passes it to the super class
     * Parameters:
     * name - Representing the Accommodation name
     */
    public Campsite(String name){
        super(name);
    }

    /**
     * This method allows you to set the siteNumber
     * Parameters:
     * siteNumber - The campground location for your tent
     * Throws:
     * IllegalArgumentException - if site number is less than 1. Message is Bad Params Campsite SetSiteNumber
     */
    public void setSiteNumber(int siteNumber){
        if(siteNumber < 1)
            throw new IllegalArgumentException("Bad Params Campsite SetSiteNumber");

        this.siteNumber = siteNumber;
    }

    /**
     * Returns the site number for the tent
     * Returns:
     * int Representing the campground location for your tent
     */
    public int getSiteNumber(){
        return siteNumber;
    }

    /**
     * Provides the site number
     * Specified by:
     * getLocation in class Accommodation
     * Returns:
     * String Representing Site number: the site number
     */
    public String getLocation(){
        return "Site number: " + this.siteNumber;
    }
}
