package cscd212accommodation;

import cscd212classes.Reservation;

public abstract class Accommodation{
    private String name;
    private Reservation reservation;

    /**
     * EVC for Accommodation
     * Parameters:
     * name - Representing the name of the accommodation
     * Throws:
     * IllegalArgumentException - if the name is null or blank. Message is Bad Params Accommodation Constructor
     */
    public Accommodation(String name) {
        if(name == null || name.isBlank())
            throw new IllegalArgumentException("Bad Params Accommodation Constructor");

        this.name = name;
    }

    /**
     * The method that sets the reservation
     * Parameters:
     * reservation - Representing a reservation
     * Throws:
     * IllegalArgumentException - if the reservation is null. Message is Bad Params Accommodation SetReservation
     */
    public void setReservation(Reservation reservation) {
        if(reservation == null)
            throw new IllegalArgumentException("Bad Params Accommodation SetReservation");

        this.reservation = reservation;
    }

    /**
     * The getReservation returns the current reservation
     * Returns:
     * Representing the current reservation
     */
    public Reservation getReservation(){
        return reservation;
    }

    /**
     * Abstract method to retreive the specific location based on the accommodation type
     * Returns:
     * String Representing the specific location based on the accommodation type
     */
    public abstract String getLocation();

    /**
     * The toString
     * Overrides:
     * toString in class Object
     * Returns:
     * Representing the String Lodging: the name then checks if reservation is null if it is location is returned
     * if reservation is not null it returns Reservation: cr tab Arrival Date: the date cr tab Number of Nights: the number of nights the location and a cr --- SEE SAMPLE OUTPUT
     */
    @Override
    public String toString() {
        if (reservation != null) {
            return "Reservation: \n\t" + "Arrival Date: " + reservation.getArrivalDate() + "\n\t" + "Number of nights: " + this.reservation.getNights();
        } else {
            return null;
        }
    }
}



// toString
// #1
//    @Override
//    public String toString() {
//        if (reservation != null) {
//            return "Reservation: " + reservation + ", Arrival Date: " + reservation.getArrivalDate() + ", Number of Nights: " + reservation.getNights() + ", Location: " + getLocation();
//        } else {
//            return "Lodging: " + name + ", Location: " + getLocation();
//        }
//    }


// #2
//    public String toString() {
//        String result;
//        if(reservation != null) {
//            return "Reservation: " + reservation + "Arrivial Date: " + getReservation().getArrivalDate() + "Number of nights: " + getReservation().getNights();
//        }
//        return result;
//    }


