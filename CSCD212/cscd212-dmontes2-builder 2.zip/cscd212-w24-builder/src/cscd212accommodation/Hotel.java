package cscd212accommodation;

public class Hotel extends Accommodation{
    private int roomNumber;

    /**
     * The EVC that is passed an Accommodation name and passes it to the super class
     * Parameters:
     * name - Representing the Accommodation name
     */
    public Hotel(String name){
        super(name);
    }

    /**
     * Sets the room number
     * Parameters:
     * roomNumber - Representing the room number
     * Throws:
     * IllegalArgumentException - if roomnumber is less than 1. Message is Bad Params Hotel SetRoomNumber
     */
    public void setRoomNumber(int roomNumber){
        if(roomNumber < 1)
            throw new IllegalArgumentException("Bad Params Hotel SetRoomNumber");

        this.roomNumber = roomNumber;
    }

    /**
     * Gets the room number
     * Returns:
     * int Reperesenting the room number
     */
    public int getRoomNumber(){
        return roomNumber;
    }

    /**
     * Gets the location.
     * Specified by:
     * getLocation in class Accommodation
     * Returns:
     * String representing the location. If room number is 0 returns empty string otherwise Room number: the room number
     */
    public String getLocation(){
        return "Room number: " + this.roomNumber;
    }
}
