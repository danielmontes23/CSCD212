package cscd212builder;

import cscd212accommodation.Accommodation;
import cscd212accommodation.AirBnB;
import cscd212accommodation.Campsite;
import cscd212classes.Reservation;

public class OutdoorVacationBuilder extends VacationBuilder{
    /**
     * The constructor that takes the name of the outdoor vacation and passes it to the super class
     * Parameters:
     * name - Representing the Vacation Builder name
     * @param name
     */
    public OutdoorVacationBuilder(String name){
        super(name);
    }

    /**
     * The addAccommodation method adds the accommodations to the superclass arraylist
     * Specified by:
     * addAccommodation in class VacationBuilder
     * Parameters:
     * type - Representing an accommodation
     * Returns:
     * VacationBuilder Represented by this object
     * Throws:
     * IllegalArgumentException - if type is null. Message is Bad Params OutdoorVacationBuilder AddAccommodation
     * @param type
     * @return
     */
    public VacationBuilder addAccommodation(Accommodation type){
        if(type == null)
            throw new IllegalArgumentException("Bad Params OutdoorVacationBuilder AddAccommodation");

        this.accommodations.add(type);
        return this;
    }

    /**
     * This addAccommodation builds a new reservation, sets the arrival date, sets the night, creates a Campsite object, sets the reservation, and the site number, and finally adds the accommodation to the arraylist
     * Specified by:
     * addAccommodation in class VacationBuilder
     * Parameters:
     * name - Representing the name of the VacationBuilder
     * year - Representing the reservation year
     * month - Representing the reservation month
     * day - Representing the reservation day
     * nights - Representing the reservations nights
     * location - Representing the hotel room number
     * Returns:
     * VacationBuilder Represented by this object
     * Throws:
     * IllegalArgumentException - if name is null or blank or the location is less than 1. Message is Bad Params OutdoorVacationBuilder AddAccommodation
     */
    public VacationBuilder addAccommodation(String name, int year, int month, int day, int nights, int location){
        if(name == null || name.isBlank() || location < 1)
            throw new IllegalArgumentException("Bad Params OutdoorVacationBuilder AddAccommodation");

        Reservation reservation = new Reservation();
        reservation.setArrivalDate(year, month, day);
        reservation.setNights(nights);

        Campsite campsite = new Campsite(name);
        campsite.setReservation(reservation);
        campsite.setSiteNumber(location);


        return this;
    }

    /**
     * This addAccommodation builds a new reservation, sets the arrival date, sets the night, creates an AirBnB object, sets the reservation for the AirBnB, and the address, and finally adds the accommodation to the arraylist
     * Specified by:
     * addAccommodation in class VacationBuilder
     * Parameters:
     * name - Representing the name of the VacationBuilder
     * location - Representing the AirBnB location
     * year - Representing the reservation year
     * month - Representing the reservation month
     * day - Representing the reservation day
     * nights - Representing the reservations nights
     * Returns:
     * VacationBuilder Represented by this object
     * Throws:
     * IllegalArgumentException - if any of the strings are null or blank. Message is Bad Params CityVacationBuilder AddAccommodation
     */
    public VacationBuilder addAccommodation(String name, String location, int year, int month, int day, int nights){
        if(name == null || name.isBlank() || location == null || location.isBlank())
            throw new IllegalArgumentException("Bad Params OutdoorVacationBuilder AddAccommodation");

        Reservation reservation = new Reservation();
        reservation.setArrivalDate(year, month, day);
        reservation.setNights(nights);

        AirBnB airBnB = new AirBnB(location);
        airBnB.setReservation(reservation);
        airBnB.setAddress(location);

        return this;
    }

    /**
     * The addEvent methods adds an event into the super classes events arraylist
     * Specified by:
     * addEvent in class VacationBuilder
     * Parameters:
     * event - Representing an event
     * Returns:
     * VacationBuilder Represented by this object
     * Throws:
     * IllegalArgumentException - if event is null or blank. Message is Bad Params CityVacationBuilder AddEvent
     */
    public VacationBuilder addEvent(String event){
        if(event == null || event.isBlank())
            throw new IllegalArgumentException("Bad Params OutdoorVacationBuilder AddEvent");

        this.events.add(event);
        return this;
    }
}
