package cscd212builder;

import cscd212accommodation.Accommodation;
import cscd212classes.Vacation;

import java.util.ArrayList;
import java.util.List;

public abstract class VacationBuilder{

    protected List <Accommodation> accommodations;
    protected List <String> events;
    private String name;

    /**
     * The EVC receives the name from the subclasses and sets it. It then creates empty default sized arraylists for accommdations and events
     * Parameters:
     * name - Representing the vacation builder name
     * Throws:
     * IllegalArgumentException - if name is null or blank. Message is Bad Param VacationBuilder Constructor
     * @param name
     */
    public VacationBuilder(String name){
        if(name == null || name.isBlank())
            throw new IllegalArgumentException("Bad Param VacationBuilder Constructor");

        this.name = name;
        this.accommodations = new ArrayList<>();
        this.events = new ArrayList<>();
    }

    /**
     * The addAccommdations method that must be overriden by the child class
     * Parameters:
     * type - Representing the accommdation
     * Returns:
     * VacationBuilder object in the child class
     * @param type
     * @return
     */
    public abstract VacationBuilder addAccommodation(Accommodation type);

    /**
     *
     * @param name
     * @param year
     * @param month
     * @param day
     * @param nights
     * @param location
     * @return
     */
    public abstract VacationBuilder addAccommodation(String name, int year, int month, int day, int nights, int location);

    /**
     * The addAccommdations method that must be overriden by the child class
     * Parameters:
     * name - The accommodation name
     * location - The accommodation location
     * year - The reservation year
     * month - The reservation month
     * day - The reservation day
     * nights - The reservation number of nights
     * Returns:
     * VacationBuilder object in the child class
     */
    public abstract VacationBuilder addAccommodation(String name, String location, int year, int month, int day, int nights);

    /**
     * This method that must be overriden by the child class
     * Parameters:
     * event - The event
     * Returns:
     * VacationBuilder object in the child class
     * @param event
     * @return
     */
    public abstract VacationBuilder addEvent(String event);

    /**
     * The getVacation returns a vaction object. It creates the vacation object passing the name, sets the accommodations and sets the events
     * Returns:
     * Vacation Representing the object created in the method
     * @return
     */
    public Vacation getVacation(){
        Vacation vacation = new Vacation(name);
        vacation.setAccommodations(accommodations);
        vacation.setEvents(events);
        return vacation;
    }
}
