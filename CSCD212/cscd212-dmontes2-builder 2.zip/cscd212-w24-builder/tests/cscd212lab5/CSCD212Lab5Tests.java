package cscd212lab5;

import cscd212accommodation.Accommodation;
import cscd212accommodation.AirBnB;
import cscd212accommodation.Campsite;
import cscd212accommodation.Hotel;
import cscd212builder.CityVacationBuilder;
import cscd212builder.OutdoorVacationBuilder;
import cscd212builder.VacationBuilder;
import cscd212classes.Reservation;
import cscd212classes.Vacation;
import org.junit.jupiter.api.*;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class CSCD212Lab5Tests {

    @Nested
    class BuilderExceptions {
        @Test
        void constuter() {
            // NOTE: bad having mutable asserts
            Throwable throwable;
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new CityVacationBuilder(null);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Param VacationBuilder Constructor".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new OutdoorVacationBuilder(null);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Param VacationBuilder Constructor".strip().toLowerCase(),throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new CityVacationBuilder(" \t \t ");
            }, "CityVacationBuilder missing blank check");
            assertEquals("Bad Param VacationBuilder Constructor".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new OutdoorVacationBuilder(" \t \t ");
            }, "OutdoorVacationBuilder missing blank check");
//            assertEquals("Bad Param VacationBuilder Constructor".strip().toLowerCase(),throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");
        }

        @Test
        void addAccommodation() {
            // NOTE: bad having mutable asserts
            // ##############################################
            // # addAccommodation(final Accommodation type) #
            // ##############################################
            Throwable throwable;
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new CityVacationBuilder("testing").addAccommodation(null);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddAccommodation".strip().toLowerCase(),
                    throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new OutdoorVacationBuilder("testing").addAccommodation(null);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddAccommodation".strip().toLowerCase(),
//                    throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");

            // #######################################################
            // # addAccommodation(String name, String location, ...) #
            // #######################################################
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new CityVacationBuilder("testing").addAccommodation(null, "testing", 0, 0, 0, 0);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddAccommodation".strip().toLowerCase(),
                    throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new OutdoorVacationBuilder("testing").addAccommodation(null, "testing", 0, 0, 0, 0);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddAccommodation".strip().toLowerCase(),
//                    throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new CityVacationBuilder("testing").addAccommodation("testing", null, 0, 0, 0, 0);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddAccommodation".strip().toLowerCase(),
                    throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new OutdoorVacationBuilder("testing").addAccommodation("testing", null, 0, 0, 0, 0);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddAccommodation".strip().toLowerCase(),
//                    throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new CityVacationBuilder("testing").addAccommodation(null, " \t \t ", 0, 0, 0, 0);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddAccommodation".strip().toLowerCase(),
                    throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new OutdoorVacationBuilder("testing").addAccommodation(null, " \t \t ", 0, 0, 0, 0);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddAccommodation".strip().toLowerCase(),
//                    throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new CityVacationBuilder("testing").addAccommodation(" \t \t ", null, 0, 0, 0, 0);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddAccommodation".strip().toLowerCase(),
                    throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new OutdoorVacationBuilder("testing").addAccommodation(" \t \t ", null, 0, 0, 0, 0);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddAccommodation".strip().toLowerCase(),
//                    throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new CityVacationBuilder("testing").addAccommodation("testing", " \t \t ", 0, 0, 0, 0);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddAccommodation".strip().toLowerCase(),
                    throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new OutdoorVacationBuilder("testing").addAccommodation("testing", " \t \t ", 0, 0, 0, 0);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddAccommodation".strip().toLowerCase(),
//                    throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new CityVacationBuilder("testing").addAccommodation(" \t \t ", "testing", 0, 0, 0, 0);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddAccommodation".strip().toLowerCase(),
                    throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                new OutdoorVacationBuilder("testing").addAccommodation(" \t \t ", "testing", 0, 0, 0, 0);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddAccommodation".strip().toLowerCase(),
//                    throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");

            // ####################################################
            // # addAccommodation(String name, ..., int location) #
            // ####################################################
            // TODO: add tests
        }

        @Test
        void addEvent() {
            // NOTE: bad having mutable asserts
            Throwable throwable;
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new CityVacationBuilder("testing");
                vb.addEvent(null);
            }, "CityVacationBuilder missing null check");
            assertEquals("Bad Params CityVacationBuilder AddEvent".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new OutdoorVacationBuilder("testing");
                vb.addEvent(null);
            }, "OutdoorVacationBuilder missing null check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddEvent".strip().toLowerCase(),throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new CityVacationBuilder("testing");
                vb.addEvent(" \t \t ");
            }, "CityVacationBuilder missing blank check");
            assertEquals("Bad Params CityVacationBuilder AddEvent".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                VacationBuilder vb = new OutdoorVacationBuilder("testing");
                vb.addEvent(" \t \t ");
            }, "OutdoorVacationBuilder missing blank check");
//            assertEquals("Bad Params OutdoorVacationBuilder AddEvent".strip().toLowerCase(),throwable.getMessage().strip().toLowerCase(),
//                    "Incorrect message for exception");
        }
    }

    @Nested
    class BuilderEvents {
        VacationBuilder cvb;
        VacationBuilder ovb;
        List<String> cevents;
        List<String> oevents;

        @BeforeEach
        void init() throws NoSuchFieldException, IllegalAccessException {
            cvb = new CityVacationBuilder("testing");
            ovb = new OutdoorVacationBuilder("testing");
            Field eventField = VacationBuilder.class.getDeclaredField("events");
            eventField.setAccessible(true);
            cevents = (List<String>) eventField.get(cvb);
            oevents = (List<String>) eventField.get(ovb);
        }

        @Test
        void addEventCity() {
            String event = "hello world";
            List<String> list = new ArrayList<>();
            list.add(event); // Docs does not require `"Event: " +` code
            List<String> list2 = new ArrayList<>();
            list2.add("Event: " + event);
            cvb.addEvent(event);
            assertTrue(list.equals(cevents) || list2.equals(cevents));
        }

        @Test
        void addEvent10City() {
            String event = "hello world";
            List<String> list = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                list.add(event + i); // Docs does not require `"Event: " +` code
            }
            List<String> list2 = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                list2.add("Event: " + event + i);
            }
            for (int i = 0; i < 10; i++) {
                cvb.addEvent(event + i);
            }
            assertTrue(list.equals(cevents) || list2.equals(cevents));
        }

        @Test
        void addEventOut() {
            String event = "hello world";
            List<String> list = new ArrayList<>();
            list.add(event); // Docs does not require `"Event: " +` code
            List<String> list2 = new ArrayList<>();
            list2.add("Event: " + event);
            ovb.addEvent(event);
            assertTrue(list.equals(oevents) || list2.equals(oevents));
        }

        @Test
        void addEvent10Out() {
            String event = "hello world";
            List<String> list = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                list.add(event + i); // Docs does not require `"Event: " +` code
            }
            List<String> list2 = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                list2.add("Event: " + event + i);
            }
            for (int i = 0; i < 10; i++) {
                ovb.addEvent(event + i);
            }
            assertTrue(list.equals(oevents) || list2.equals(oevents));
        }
    }

    @Nested
    class BuilderAccommodation {
        VacationBuilder cvb;
        VacationBuilder ovb;
        List<Accommodation> caccommodations;
        List<Accommodation> oaccommodations;

        @BeforeEach
        void init() throws NoSuchFieldException, IllegalAccessException {
            cvb = new CityVacationBuilder("testing");
            ovb = new OutdoorVacationBuilder("testing");
            Field accommodationsField = VacationBuilder.class.getDeclaredField("accommodations");
            accommodationsField.setAccessible(true);
            caccommodations = (List<Accommodation>) accommodationsField.get(cvb);
            oaccommodations = (List<Accommodation>) accommodationsField.get(ovb);
        }

        class testAccommodation extends Accommodation {
            public testAccommodation() {
                super("test acc");
            }

            @Override
            public String getLocation() {
                return "Address: n/a";
            }

            @Override
            public boolean equals(Object obj) {
                if (super.equals(obj)) {
                    return true;
                } else if (obj == null) {
                    return false;
                } else if (!(obj instanceof testAccommodation)) {
                    return false;
                }

                testAccommodation other = (testAccommodation) obj;

                return this.toString().equals(other.toString());
            }
        }

        @Test
        void addTestAccommodationCity() {
            Accommodation accommodation = new testAccommodation();
            List<Accommodation> list = new ArrayList<>();
            list.add(accommodation);
            cvb.addAccommodation(accommodation);
            assertEquals(list, caccommodations);
        }

        @Test
        void addTestAccommodationOut() {
            Accommodation accommodation = new testAccommodation();
            List<Accommodation> list = new ArrayList<>();
            list.add(accommodation);
            ovb.addAccommodation(accommodation);
            assertEquals(list, oaccommodations);
        }

        @Test
        void addTestAccommodationAirBnBCity() {
            String name = "Tim";
            String location = "no";
            int year = 2030;
            int month = 2;
            int day = 5;
            int nights = 3;
            Reservation reservation = new Reservation();
            reservation.setArrivalDate(year, month, day);
            reservation.setNights(nights);
            AirBnB airBnB = new AirBnB(name);
            airBnB.setReservation(reservation);
            airBnB.setAddress(location);
            List<Accommodation> list = new ArrayList<>();
            list.add(airBnB);
            cvb.addAccommodation(name, location, year, month, day, nights);
            assertEquals(list.toString(), caccommodations.toString());
        }

        @Test
        void addTestAccommodationHotelCity() {
            String name = "Tim";
            int year = 2030;
            int month = 2;
            int day = 5;
            int nights = 3;
            int location = 10;
            Reservation reservation = new Reservation();
            reservation.setArrivalDate(year, month, day);
            reservation.setNights(nights);
            Hotel hotel = new Hotel(name);
            hotel.setReservation(reservation);
            hotel.setRoomNumber(location);
            List<Accommodation> list = new ArrayList<>();
            list.add(hotel);
            cvb.addAccommodation(name, year, month, day, nights, location);
            assertEquals(list.toString(), caccommodations.toString());
        }

        @Test
        void addTestAccommodationCampsiteOut() {
            String name = "Tim";
            int year = 2030;
            int month = 2;
            int day = 5;
            int nights = 3;
            int location = 10;
            Reservation reservation = new Reservation();
            reservation.setArrivalDate(year, month, day);
            reservation.setNights(nights);
            Campsite campsite = new Campsite(name);
            campsite.setReservation(reservation);
            campsite.setSiteNumber(location);
            List<Accommodation> list = new ArrayList<>();
            list.add(campsite);
            ovb.addAccommodation(name, year, month, day, nights, location);
            assertEquals(list.toString(), oaccommodations.toString());
        }


    }

    @Nested
    class VacationTests {

        Vacation vacation;
        String name;
        List<Accommodation> accommodations;
        List<String> events;


        @BeforeEach
        void init() {
            Random random = new Random();
            this.name = "testing" + random.nextLong();
            this.accommodations = new ArrayList<>();
            for (int i = 0; i < random.nextInt(5) + 5; i++) {
                switch (random.nextInt(3)) {
                    case 0:
                        this.accommodations.add(new AirBnB(random.nextLong() + "testing"));
                        break;
                    case 1:
                        this.accommodations.add(new Campsite(random.nextLong() + "testing"));
                        break;
                    case 2:
                        this.accommodations.add(new Hotel(random.nextLong() + "testing"));
                        break;
                }
            }
            this.events = new ArrayList<>();
            for (int i = 0; i < random.nextInt(5) + 5; i++) {
                this.events.add(random.nextLong() + "testing");
            }
            this.vacation = new Vacation(this.name);
            this.vacation.setAccommodations(this.accommodations);
            this.vacation.setEvents(this.events);
        }

        @Test
        void Exceptions() {
            Throwable throwable;
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Vacation vacation = new Vacation(null);
            }, "Vacation missing null check");
            assertEquals("Bad Params Vacation Constructor".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Vacation vacation = new Vacation(" \t \t ");
            }, "Vacation missing emtpy string check");
            assertEquals("Bad Params Vacation Constructor".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Vacation vacation = new Vacation("test");
                vacation.setAccommodations(null);
            }, "Vacation set missing null check");
            assertEquals("Bad Params Vacation SetAccommodations".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Vacation vacation = new Vacation("test");
                vacation.setEvents(null);
            }, "Vacation set missing null check");
            assertEquals("Bad Params Vacation SetEvents".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
        }

        @RepeatedTest(3)
        void isName() throws NoSuchFieldException, IllegalAccessException {
            Field nameField = Vacation.class.getDeclaredField("name");
            nameField.setAccessible(true);
            assertEquals(this.name, nameField.get(this.vacation));
        }

        @RepeatedTest(3)
        void isEvents() throws NoSuchFieldException, IllegalAccessException {
            Field field = Vacation.class.getDeclaredField("events");
            field.setAccessible(true);
            assertEquals(this.events, field.get(this.vacation));
        }

        @RepeatedTest(3)
        void isAccommodations() throws NoSuchFieldException, IllegalAccessException {
            Field field = Vacation.class.getDeclaredField("accommodations");
            field.setAccessible(true);
            assertEquals(this.accommodations, field.get(this.vacation));
        }
    }

    @Nested
    class ReservationTests {

        Reservation reservation;
        int year;
        int month;
        int day;
        int nights;

        @BeforeEach
        void init() {
            Random random = new Random();
            this.year = random.nextInt(5) + 2023;
            this.month = random.nextInt(12) + 1;
            this.day = random.nextInt(20) + 1;
            this.nights = random.nextInt(15) + 1;
            this.reservation = new Reservation();
            this.reservation.setArrivalDate(this.year, this.month, this.day);
            this.reservation.setNights(this.nights);
        }

        @Test
        void Exceptions() {
            Throwable throwable;
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Reservation reservation = new Reservation();
                reservation.setArrivalDate(20, 5, 5);
            }, "setArrivalDate set missing check");
            assertEquals("Bad Params Reservation SetArrivalDate".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Reservation reservation = new Reservation();
                reservation.setArrivalDate(2023, -1, 5);
            }, "setArrivalDate set missing check");
            assertEquals("Bad Params Reservation SetArrivalDate".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Reservation reservation = new Reservation();
                reservation.setArrivalDate(2023, 50, 5);
            }, "setArrivalDate set missing check");
            assertEquals("Bad Params Reservation SetArrivalDate".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Reservation reservation = new Reservation();
                reservation.setArrivalDate(2023, 5, 50);
            }, "setArrivalDate set missing check");
            assertEquals("Bad Params Reservation SetArrivalDate".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Reservation reservation = new Reservation();
                reservation.setArrivalDate(2023, 5, -1);
            }, "setArrivalDate set missing check");
            assertEquals("Bad Params Reservation SetArrivalDate".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Reservation reservation = new Reservation();
                reservation.setNights(0);
            }, "setNights set missing check");
            assertEquals("Bad Params Reservation SetNights".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
        }

        @RepeatedTest(3)
        void setArrivalDateTest() throws NoSuchFieldException, IllegalAccessException {
            Field field = Reservation.class.getDeclaredField("arrivalDate");
            field.setAccessible(true);
            LocalDate localDate = LocalDate.of(this.year, this.month, this.day);
            assertEquals(localDate, field.get(this.reservation));
        }

        @RepeatedTest(3)
        void getArrivalDateTest() {
            LocalDate localDate = LocalDate.of(this.year, this.month, this.day);
            assertEquals(localDate, this.reservation.getArrivalDate());
        }

        @RepeatedTest(3)
        void setNightsTest() throws NoSuchFieldException, IllegalAccessException {
            Field field = Reservation.class.getDeclaredField("nights");
            field.setAccessible(true);
            assertEquals(this.nights, field.get(this.reservation));
        }

        @RepeatedTest(3)
        void getNightsTest() {
            assertEquals(this.nights, this.reservation.getNights());
        }
    }

    @Nested
    class AccommodationTests {

        Random random;

        @BeforeEach
        void init() {
            this.random = new Random();
        }


        class testAccommodation extends Accommodation {
            public testAccommodation(String name) {
                super(name);
            }

            @Override
            public String getLocation() {
                return "n/a";
            }
        }

        @Test
        void Exceptions() {

            Throwable throwable;
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Accommodation accommodation = new testAccommodation(null);
            }, "Accommodation Constructor missing null check");
            assertEquals("Bad Params Accommodation Constructor".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Accommodation accommodation = new testAccommodation(" \t \t ");
            }, "Accommodation Constructor missing blank check");
            assertEquals("Bad Params Accommodation Constructor".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Accommodation accommodation = new testAccommodation("testing");
                accommodation.setReservation(null);
            }, "setReservation missing check");
            assertEquals("Bad Params Accommodation SetReservation".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                AirBnB accommodation = new AirBnB("testing");
                accommodation.setAddress(null);
            }, "setAddress missing null check");
            assertEquals("Bad Params AirBnB SetAddress".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
            throwable = assertThrows(IllegalArgumentException.class, () -> {
                AirBnB accommodation = new AirBnB("testing");
                accommodation.setAddress(" \t \t ");
            }, "setAddress missing blank check");
            assertEquals("Bad Params AirBnB SetAddress".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Campsite accommodation = new Campsite("testing");
                accommodation.setSiteNumber(0);
            }, "SetSiteNumber missing check");
            assertEquals("Bad Params Campsite SetSiteNumber".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");

            throwable = assertThrows(IllegalArgumentException.class, () -> {
                Hotel accommodation = new Hotel("testing");
                accommodation.setRoomNumber(0);
            }, "SetRoomNumber missing check");
            assertEquals("Bad Params Hotel SetRoomNumber".strip().toLowerCase(), throwable.getMessage().strip().toLowerCase(),
                    "Incorrect message for exception");
        }


        @RepeatedTest(3)
        void isName() throws NoSuchFieldException, IllegalAccessException {
            Field field = Accommodation.class.getDeclaredField("name");
            field.setAccessible(true);
            String name = "testing" + this.random.nextLong();
            Accommodation accommodation = new testAccommodation(name);
            assertEquals(name, field.get(accommodation));
        }

        @RepeatedTest(3)
        void isReservation() throws NoSuchFieldException, IllegalAccessException {
            Field field = Accommodation.class.getDeclaredField("reservation");
            field.setAccessible(true);
            Reservation reservation = new Reservation();
            int year = random.nextInt(5) + 2023;
            int month = random.nextInt(12) + 1;
            int day = random.nextInt(30) + 1;
            int nights = random.nextInt(15) + 1;
            reservation.setArrivalDate(year, month, day);
            reservation.setNights(nights);
            Accommodation accommodation = new testAccommodation("testing");
            accommodation.setReservation(reservation);
            assertEquals(reservation, field.get(accommodation));
        }

        @RepeatedTest(3)
        void getReservation() {
            Reservation reservation = new Reservation();
            int year = random.nextInt(5) + 2023;
            int month = random.nextInt(12) + 1;
            int day = random.nextInt(30) + 1;
            int nights = random.nextInt(15) + 1;
            reservation.setArrivalDate(year, month, day);
            reservation.setNights(nights);
            Accommodation accommodation = new testAccommodation("testing");
            accommodation.setReservation(reservation);
            assertEquals(reservation, accommodation.getReservation());
        }

        @RepeatedTest(3)
        void isAddress() throws NoSuchFieldException, IllegalAccessException {
            Field field = AirBnB.class.getDeclaredField("address");
            field.setAccessible(true);
            String add = "Testing" + random.nextLong();
            AirBnB accommodation = new AirBnB("testing");
            accommodation.setAddress(add);
            assertEquals(add, field.get(accommodation));
        }

        @RepeatedTest(3)
        void getAddress() {
            String add = "Testing" + random.nextLong();
            AirBnB accommodation = new AirBnB("testing");
            accommodation.setAddress(add);
            assertEquals(add, accommodation.getAddress());
        }

        @RepeatedTest(3)
        void isSiteNumber() throws NoSuchFieldException, IllegalAccessException {
            Field field = Campsite.class.getDeclaredField("siteNumber");
            field.setAccessible(true);
            int siteNumber = random.nextInt(1000) + 1;
            Campsite accommodation = new Campsite("testing");
            accommodation.setSiteNumber(siteNumber);
            assertEquals(siteNumber, field.get(accommodation));
        }

        @RepeatedTest(3)
        void getSiteNumber() {
            int siteNumber = random.nextInt(1000) + 1;
            Campsite accommodation = new Campsite("testing");
            accommodation.setSiteNumber(siteNumber);
            assertEquals(siteNumber, accommodation.getSiteNumber());
        }

        @RepeatedTest(3)
        void isRoomNumber() throws NoSuchFieldException, IllegalAccessException {
            Field field = Hotel.class.getDeclaredField("roomNumber");
            field.setAccessible(true);
            int roomNumber = random.nextInt(1000) + 1;
            Hotel accommodation = new Hotel("testing");
            accommodation.setRoomNumber(roomNumber);
            assertEquals(roomNumber, field.get(accommodation));
        }

        @RepeatedTest(3)
        void getRoomNumber() {
            int roomNumber = random.nextInt(1000) + 1;
            Hotel accommodation = new Hotel("testing");
            accommodation.setRoomNumber(roomNumber);
            assertEquals(roomNumber, accommodation.getRoomNumber());
        }

    }


//// Tests written by me
// 59/63 Tests passed before my tests BUT one test was failing because the actual and expected, but I had it correct we talked about it in class and I couldn't fix it.

    @Test
    @DisplayName("toStringwithReservation")
    public void testToStringWithReservation() {

        Reservation reservation = new Reservation();

        String expected = "Reservation: \n\tArrival Date: " + reservation.getArrivalDate() + "\n\tNumber of nights: " + reservation.getNights();
        assertEquals(expected, reservation.toString());
    }

    @Test
    @DisplayName("withoutReservation")
    public void testToStringWithoutReservation() {
        Reservation reservation = new Reservation();

        assertEquals(null, reservation.toString());
    }

    @Test
    @DisplayName("Reservation Arrival Date")
    public void testSetArrivalDateValid() {
        Reservation reservation = new Reservation();

        reservation.setArrivalDate(2023, 1, 15);

        assertEquals(2023, reservation.getArrivalDate().getYear());
        assertEquals(1, reservation.getArrivalDate().getMonthValue());
        assertEquals(15, reservation.getArrivalDate().getDayOfMonth());
    }

    //@Test
    //@DisplayName("AccommodationConstructor")
    //public void testConstructorValidName() {
    //    Accommodation accommodation = new Accommodation();

    //    assertEquals(getClass(), accommodation);
    //}


    //@Test
    //@DisplayName("addAccommodation")
    //public void testAddAccommodationNull() {
    //    VacationBuilder vacationBuilder = new VacationBuilder();

    //    vacationBuilder.addAccommodation(null);
    //}


    //@Test
    //@DisplayName("Campsite Site Number")
    //public void testGetLocation() {

    //    Accommodation accommodation = new Accommodation();

    //    assertEquals("Site number: ", accommodation.getLocation());
    //}


    //@Test
    //@DisplayName("Hotel Room Number")
    //public void testGetLocation() {
    //    Accommodation accommodation = new Accommodation();

    //    assertEquals("Site number: ", accommodation.getLocation());
    //}
}