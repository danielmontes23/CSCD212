package cscd212lab4;

import cscd212classes.decorations.Angel;
import cscd212classes.decorations.BallsGreen;
import cscd212classes.decorations.SnowflakesClear;
import cscd212classes.decorations.HolidayItemDecorator;
import cscd212classes.decorations.LightsLED;
import cscd212classes.decorations.RedRibbon;
import cscd212classes.decorations.Star;
import cscd212classes.decorations.GoldTinsel;
import cscd212classes.trees.BalsamFir;
import cscd212classes.trees.ColoradoBlueSpruce;
import cscd212classes.trees.Tree;
import cscd212interfaces.HolidayItem;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Random;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

// Tests in this file written by me Daniel Montes
public class CSCD212Lab4Tester {

    //    @Test
//    @DisplayName("BalsamTreeType")
//    void BalsamFir(double description, double cost){
//        BalsamFir newTree = new BalsamFir(cost);
//        assertEquals(getItemCost();
//    }

    @Test
    @DisplayName("BalsamFirPrice")
    void testBalsamFirCost() {
        double cost = 110.0; //Random price
        BalsamFir newTree = new BalsamFir(cost);
        assertEquals(cost, newTree.getCost());
    }

    @Test
    @DisplayName("ColoradoBlueSprucePrice")
    void testColoradoBlueSpruceCost() {
        double cost = 120.0; //Random price
        ColoradoBlueSpruce newTree = new ColoradoBlueSpruce(cost);
        assertEquals(cost, newTree.getCost());
    }

    @Test
    @DisplayName("ColoradoBlueSpruceDescription")
    void testColoradoBlueSpruceDescription(int description) {
        String expectedDescription = "Description: ColoradoBlueSpruce"; // Expected
        ColoradoBlueSpruce newTree = new ColoradoBlueSpruce(description);
        assertEquals(expectedDescription, newTree.getDescription());
    }

    @Test
    @DisplayName("BalsamFirDescription")
    void testBalsamFirDescription(int description) {
        String expectedDescription = "Description: BalsamFir"; // Expected
        BalsamFir newTree = new BalsamFir(description);
        assertEquals(expectedDescription, newTree.getDescription());
    }

//    @Test
//    @DisplayName("Test Tree Negative numbers")
//    void testTreeNegativeNumbers(double cost) {
//        String invalidTreeType = null;
//        if(cost <= 0){
//            assertThrows(IllegalAccessError.class, new Tree invalidTreeType);
//        }
//    }

//    @Test
//    @DisplayName("Tree")
//    void TreeName(String treeType, double cost){
//        treeType = new
//    }

//    @Test
//    @DisplayName("BalsamTreeType")
//    void BalsamFir(double cost){
//        BalsamFir newTree = new BalsamFir(cost);
//        assertEquals(getDescription, cost);
//    }

//    @Test
//    @DisplayName("ColoradoBlueSpruceTree")
//    void ColoradoBlueSpruce(double cost){
//        ColoradoBlueSpruce newTree = new BalsamFir(cost);
//        assertEquals(newTree, cost);
//    }
}
