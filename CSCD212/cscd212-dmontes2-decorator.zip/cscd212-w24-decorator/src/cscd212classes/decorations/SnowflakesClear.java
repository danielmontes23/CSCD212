package cscd212classes.decorations;

import cscd212interfaces.HolidayItem;

public class SnowflakesClear extends HolidayItemDecorator {

     /** This constructor calls the parent constructor passing the item, the class Name, and the cost
     * Parameters:
            * item - Representing the HolidayItem
     * cost - Representing the cost
     * @param item
     * @param costs
     */
    public SnowflakesClear(HolidayItem item, double costs){
        super(item, "Snowflakes Clear", costs);
    }

    /**
     * Description copied from interface: HolidayItem
     * The getCost method
     * Returns:
     * doubl Representing the cost
     * @return
     */
    public double getCost(){
        return item.getCost() + cost;
    }

    /**
     * Description copied from class: HolidayItemDecorator
     * The abstract method the returns the decoration's description
     * Specified by:
     * getDescription in interface HolidayItem
     * Specified by:
     * getDescription in class HolidayItemDecorator
     * Returns:
     * String Representing the decoration's description
     * @return
     */
    public String getDescription(){
        return item.getDescription() + "Red Ball Ornaments, ";
    }
}
