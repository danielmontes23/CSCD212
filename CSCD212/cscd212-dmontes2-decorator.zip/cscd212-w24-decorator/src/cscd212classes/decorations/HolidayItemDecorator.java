package cscd212classes.decorations;

import cscd212interfaces.HolidayItem;

public abstract class HolidayItemDecorator implements HolidayItem {

    protected double cost;
    protected HolidayItem item;
    protected String name;

    /**
     * The constructor that sets all the parameters
     * Parameters:
     * item - Representing the HolidayItem
     * name - Representing the name of the decoration
     * cost - Representing the cost of the decoration
     * Throws:
     * IllegalArgumentException - if the String is null or blank
     * @param item
     * @param name
     * @param cost
     */
    public HolidayItemDecorator(HolidayItem item, String name, double cost){
        if(name == null || name.isBlank())
            throw new IllegalArgumentException("Holiday Decorator Constructor");
        this.item = item;
        this.name = name;
        this.cost = cost;
    }

    /**
     * Returns this decoration's cost
     * Returns:
     * double Representing this decoration's cost
     * @return
     */
    protected double getItemCost(){
        return cost;
    }

    /**
     * Returns this decoration name
     * Returns:
     * String Representing this decoration's name
     * @return
     */
    protected String getName(){
        return name;
    }

    /**
     * The abstract method the returns the decoration's description
     * Specified by:
     * getDescription in interface HolidayItem
     * Returns:
     * String Representing the decoration's description
     * @return
     */
    public abstract String getDescription();
}
