package cscd212classes.trees;

public class BalsamFir extends Tree{

    /**
     * The constructor that takes the hard coded name and the cost
     * Parameters:
     * cost - Representing the Cost
     * @param cost
     */
    public BalsamFir(double cost){
        super("Balsam Fir", cost);
    }
}
