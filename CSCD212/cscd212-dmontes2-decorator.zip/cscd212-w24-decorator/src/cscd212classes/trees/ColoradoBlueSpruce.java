package cscd212classes.trees;

public class ColoradoBlueSpruce extends Tree{

    /**
     * The constructor that takes the hard coded name and the cost
     * Parameters:
     * cost - Representing the Cost
     * @param cost
     */
    public ColoradoBlueSpruce(double cost) {
        super("Colorado Blue Spruce", cost);
    }
}
