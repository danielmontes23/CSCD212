package cscd212classes.trees;

import cscd212interfaces.HolidayItem;

public abstract class Tree implements HolidayItem {

    protected double cost;
    private String treeType;

    /**
     * The constructor that takes the treeType and the cost
     * Parameters:
     * treeType - Representing the tree
     * cost - Representing the tree cost
     * Throws:
     * IllegalArgumentException - if the treeType is null or blank of less than 0
     * @param treeType
     * @param cost
     */
    public Tree(String treeType, double cost){
        if(treeType == null || cost < 0)
            throw new IllegalArgumentException("Tree constructor");
        this.cost = cost;
        this.treeType = treeType;
    }

    /**
     * Returns the tree cost
     * Specified by:
     * getCost in interface HolidayItem
     * Returns:
     * double Representing the tree cost
     * @return
     */
    public double getCost(){
        return cost;
    }

    /**
     * Returns My tree 'is a' the tree type 'with'
     * Specified by:
     * getDescription in interface HolidayItem
     * Returns:
     * String My tree 'is a' the tree type 'with'
     * @return
     */
    public String getDescription(){
        return "My tree is a " + treeType + " with ";
    }

    /**
     * Returns My tree 'is a' the tree type
     * Overrides:
     * toString in class Object
     * Returns:
     * String My tree 'is a' the tree type
     * @return
     */
    @Override
    public String toString(){
        return "My tree is a " + treeType;
    }
}
