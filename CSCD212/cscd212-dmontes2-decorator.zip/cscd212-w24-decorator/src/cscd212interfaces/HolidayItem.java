package cscd212interfaces;

public interface HolidayItem {

    /**
     * The getCost method
     * Returns:
     * doubl Representing the cost
     * @return
     */
    double getCost();

    /**
     * The getDescription method
     * Returns:
     * String Representing the description
     * @return
     */
    String getDescription();
}
