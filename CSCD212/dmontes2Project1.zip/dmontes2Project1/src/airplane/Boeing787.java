package airplane;

public class Boeing787 extends Aircraft{

    /**
     * Airplane type, name, number of rows, seats per row, and total seats available
     */
    public Boeing787(){
        super("Boeing 787", 60, 5, 300);
    }
}
