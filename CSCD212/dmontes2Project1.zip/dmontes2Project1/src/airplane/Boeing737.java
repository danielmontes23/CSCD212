package airplane;

public class Boeing737 extends Aircraft{

    /**
     * Airplane type, name, number of rows, seats per row, and total seats available
     */
    public Boeing737(){
        super("Boeing737",50, 4, 200);
    }
}
