package airplane;

public class An225 extends Aircraft{

    /**
     * Airplane type, name, number of rows, seats per row, and total seats available
     */
    public An225(){
        super("Antonov An-225",80, 5, 400);
    }
}
