package airline;

public abstract class Airline {
    private String name;

    /**
     *
     * @param name
     */
    public Airline(String name){
        this.name = name;
    }
}
