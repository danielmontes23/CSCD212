package airport;

public class SeaTac extends Airport{
    //private static final String SeaTac = "Seattle Airport";
    public SeaTac(){
        super("Seattle-Tacoma Internation Airport", "Sea-Tac");
    }

    /**
     * Landing location
     * @return
     */
//    public String getLocation(){
//        return "You will land in " + getLocation() + "airport.";
//    }
}
