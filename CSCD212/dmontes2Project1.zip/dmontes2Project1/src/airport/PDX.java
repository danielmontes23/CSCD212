package airport;

public class PDX extends Airport{

    //private static final String PDX = "Portland Airport";
    public PDX() {
        super("Portland Airport", "PDX");
    }

    /**
     * Landing location
     * @return
     */
//    public String getLocation(){
//        return "You will land in " + getLocation() + "airport.";
//    }
}
