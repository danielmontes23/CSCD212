public class SeatType {

    private int firstClass;
    private int economyClass;

    /**
     *
     * @param firstClass
     * @param economyClass
     */
    public SeatType(int firstClass, int economyClass){
        this.firstClass = firstClass;
        this.economyClass = economyClass;
    }
}
